import { createServerFn } from "@tanstack/react-start";
import { extractFlows, newsAggregates, toNewsItem } from "@/lib/classify";
import { buildModel, effectLine } from "@/lib/quant";
import { buildTech, type Candle } from "@/lib/tape";
import type { DeskOk, DeskResult, NewsItem, Quote } from "@/lib/types";

type Bar = { t: number; c: number };

type YahooChart = {
  chart?: {
    result?: Array<{
      meta?: {
        regularMarketPrice?: number;
        regularMarketChangePercent?: number;
        regularMarketTime?: number;
      };
      timestamp?: number[];
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>;
          high?: Array<number | null>;
          low?: Array<number | null>;
          close?: Array<number | null>;
          volume?: Array<number | null>;
        }>;
      };
    }> | null;
  };
};

const SERIES = [
  { symbol: "GC=F", id: "gold" },
  { symbol: "DX-Y.NYB", id: "dxy" },
  { symbol: "^TNX", id: "us10y" },
  { symbol: "^VIX", id: "vix" },
  { symbol: "GLD", id: "gld" },
  { symbol: "SI=F", id: "silver" },
] as const;

let cache: { at: number; data: DeskOk } | null = null;
const TTL_MS = 60_000;

function cleanBars(payload: YahooChart): { bars: Bar[]; price: number | null; changePct: number | null; time: number | null } {
  const row = payload.chart?.result?.[0];
  if (!row) return { bars: [], price: null, changePct: null, time: null };
  const ts = row.timestamp ?? [];
  const closes = row.indicators?.quote?.[0]?.close ?? [];
  const bars: Bar[] = [];
  for (let i = 0; i < ts.length; i++) {
    const c = closes[i];
    const t = ts[i];
    if (typeof c === "number" && Number.isFinite(c) && typeof t === "number") bars.push({ t, c });
  }
  const price = row.meta?.regularMarketPrice ?? bars[bars.length - 1]?.c ?? null;
  let changePct = row.meta?.regularMarketChangePercent ?? null;
  if ((changePct == null || !Number.isFinite(changePct)) && bars.length >= 2) {
    const last = bars[bars.length - 1]!.c;
    const prev = bars[bars.length - 2]!.c;
    changePct = prev ? ((last - prev) / prev) * 100 : null;
  }
  return { bars, price, changePct, time: row.meta?.regularMarketTime ?? null };
}

async function fetchChart(symbol: string, interval = "1d", range = "6mo") {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
  const res = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "AurumDesk/1.0" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) throw new Error(`Không lấy được ${symbol}`);
  return (await res.json()) as YahooChart;
}

function toCandles(payload: YahooChart): Candle[] {
  const row = payload.chart?.result?.[0];
  if (!row) return [];
  const ts = row.timestamp ?? [];
  const quote = row.indicators?.quote?.[0];
  const opens = quote?.open ?? [];
  const highs = quote?.high ?? [];
  const lows = quote?.low ?? [];
  const closes = quote?.close ?? [];
  const volumes = quote?.volume ?? [];
  const candles: Candle[] = [];
  for (let i = 0; i < ts.length; i++) {
    const t = ts[i];
    const c = closes[i];
    const o = opens[i];
    const h = highs[i];
    const l = lows[i];
    const v = volumes[i];
    if (typeof t !== "number" || typeof c !== "number" || !Number.isFinite(c)) continue;
    candles.push({
      t,
      o: typeof o === "number" && Number.isFinite(o) ? o : c,
      h: typeof h === "number" && Number.isFinite(h) ? h : c,
      l: typeof l === "number" && Number.isFinite(l) ? l : c,
      c,
      v: typeof v === "number" && Number.isFinite(v) ? v : 0,
    });
  }
  return candles;
}

function decode(raw: string) {
  return raw
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/<[^>]+>/g, "")
    .trim();
}

function tag(chunk: string, name: string) {
  const m = chunk.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, "i"));
  return m ? decode(m[1] ?? "") : "";
}

async function fetchFeed(query: string, lang: "vi" | "en") {
  const hl = lang === "vi" ? "vi" : "en-US";
  const gl = lang === "vi" ? "VN" : "US";
  const ceid = lang === "vi" ? "VN:vi" : "US:en";
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(`${query} when:7d`)}&hl=${hl}&gl=${gl}&ceid=${ceid}`;
  const res = await fetch(url, {
    headers: { accept: "application/rss+xml, application/xml, text/xml", "user-agent": "AurumDesk/1.0" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) return [];
  const xml = await res.text();
  const items: NewsItem[] = [];
  for (const chunk of xml.split(/<item\b/i).slice(1)) {
    const source = tag(chunk, "source");
    let title = tag(chunk, "title");
    if (source && title.endsWith(` - ${source}`)) title = title.slice(0, -(source.length + 3)).trim();
    const link = tag(chunk, "link");
    const pub = tag(chunk, "pubDate");
    const publishedAt = Number.isNaN(Date.parse(pub)) ? "" : new Date(pub).toISOString();
    const item = toNewsItem({ title, link, source, publishedAt, lang });
    if (item) items.push(item);
  }
  return items;
}

function dayLabel(unix: number) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Ho_Chi_Minh",
    day: "2-digit",
    month: "2-digit",
  }).format(new Date(unix * 1000));
}

const CAVEATS = [
  "Giá là hợp đồng COMEX (GC=F), sát XAUUSD nhưng không phải giá spot LBMA từng tick.",
  "Giờ trên bàn là GMT+7 (Asia/Ho_Chi_Minh). Phiên VP DAY và VWAP ngày cắt theo 00:00 GMT+7, không theo giờ New York.",
  "VP WEEK, VP DAY, VWAP, CVD và OBV tính từ nến M5 và H1 của GC=F. CVD không phải order-flow bid/ask thật — ước lượng theo hướng nến nhân khối lượng.",
  "US10Y là lợi suất danh nghĩa. App không có lợi suất thực TIPS.",
  "GLD trên bàn là giá chứng chỉ, không phải ounces chảy vào hay ra.",
  "Tin là tiêu đề Google News 7 ngày. Điểm tin là từ khóa, không phải đọc full bài.",
  "Dự đoán của người khác chỉ được ghi khi tiêu đề là một nhận định hướng tới, và luôn kèm tên nguồn. Dự đoán của VTUN là luật trên bốn công cụ, kèm lý do — không phải bài AI.",
  "Không ai được ghi là đang thu hoặc bán lượng lớn nếu tiêu đề hoặc sổ tay của bạn không nêu nguồn.",
  "Cảnh báo rủi ro cao là tiềm ẩn từ lệch vùng giá trị và phân kỳ, không phải khuyến nghị đầu tư.",
];

export const getDesk = createServerFn({ method: "GET" })
  .validator((input: unknown) => {
    const fresh = Boolean(
      input && typeof input === "object" && "fresh" in input && (input as { fresh?: unknown }).fresh === true,
    );
    return { fresh };
  })
  .handler(async ({ data }): Promise<DeskResult> => {
    if (!data.fresh && cache && Date.now() - cache.at < TTL_MS) return cache.data;
    try {
      const settled = await Promise.allSettled([
        ...SERIES.map(async (s) => ({ id: s.id, kind: "daily" as const, ...(cleanBars(await fetchChart(s.symbol))) })),
        fetchChart("GC=F", "5m", "5d").then((payload) => ({ id: "m5" as const, kind: "intra" as const, candles: toCandles(payload) })),
        fetchChart("GC=F", "60m", "1mo").then((payload) => ({ id: "h1" as const, kind: "intra" as const, candles: toCandles(payload) })),
      ]);
      const charts = settled.flatMap((s) => (s.status === "fulfilled" && s.value.kind === "daily" ? [s.value] : []));
      const m5 = settled.flatMap((s) => (s.status === "fulfilled" && s.value.kind === "intra" && s.value.id === "m5" ? [s.value.candles] : []));
      const h1 = settled.flatMap((s) => (s.status === "fulfilled" && s.value.kind === "intra" && s.value.id === "h1" ? [s.value.candles] : []));
      const byId = Object.fromEntries(charts.map((c) => [c.id, c])) as Record<
        (typeof SERIES)[number]["id"],
        (typeof charts)[number]
      >;
      const gold = byId.gold;
      if (!gold || gold.bars.length < 30 || gold.price == null) {
        return { ok: false, error: "Không lấy được giá vàng. Thử lại sau ít phút." };
      }

      const feeds = await Promise.allSettled([
        fetchFeed(`"gold price" OR XAUUSD OR "spot gold" OR "gold futures" OR bullion`, "en"),
        fetchFeed(`(PBOC OR "central bank" OR RBI OR GLD OR "gold ETF" OR COMEX) (gold OR bullion OR reserves OR inflow OR outflow)`, "en"),
        fetchFeed(`(Fed OR "Treasury yield" OR dollar OR sanction OR war OR ceasefire OR tariff) (gold OR bullion)`, "en"),
        fetchFeed(`giá vàng OR "vàng thế giới" OR XAUUSD`, "vi"),
      ]);
      const seen = new Set<string>();
      const news: NewsItem[] = [];
      for (const feed of feeds) {
        if (feed.status !== "fulfilled") continue;
        for (const item of feed.value) {
          if (seen.has(item.id)) continue;
          seen.add(item.id);
          news.push(item);
        }
      }
      news.sort((a, b) => (b.publishedAt || "").localeCompare(a.publishedAt || ""));
      const buckets = new Set<string>();
      const varied: NewsItem[] = [];
      for (const item of news) {
        const bucket = item.title
          .toLowerCase()
          .normalize("NFD")
          .replace(/\p{M}/gu, "")
          .replace(/\d+/g, "")
          .replace(/[^a-z\s]/g, "")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 36);
        if (buckets.has(bucket)) continue;
        buckets.add(bucket);
        varied.push(item);
      }
      const topNews = varied.slice(0, 16);
      const agg = newsAggregates(topNews);
      const model = buildModel({
        gold: gold.bars.map((b) => b.c),
        dxy: byId.dxy?.bars.map((b) => b.c) ?? [],
        yld: byId.us10y?.bars.map((b) => b.c) ?? [],
        vix: byId.vix?.bars.map((b) => b.c) ?? [],
        gld: byId.gld?.bars.map((b) => b.c) ?? [],
        silver: byId.silver?.bars.map((b) => b.c) ?? [],
        ...agg,
      });
      if (!model) return { ok: false, error: "Chưa đủ lịch sử giá để chạy mô hình." };

      const factorScore = (id: string) => model.factors.find((f) => f.id === id)?.score ?? 0;
      const quoteDefs: Array<Omit<Quote, "goldEffect"> & { effect: string }> = [
        {
          id: "gold",
          label: "XAU (GC)",
          price: gold.price,
          changePct: gold.changePct ?? 0,
          unit: "USD/oz",
          effect: "hợp đồng đang giao dịch",
        },
        {
          id: "dxy",
          label: "DXY",
          price: byId.dxy?.price ?? 0,
          changePct: byId.dxy?.changePct ?? 0,
          unit: "",
          effect: byId.dxy?.price ? effectLine(factorScore("dollar")) : "thiếu dữ liệu",
        },
        {
          id: "us10y",
          label: "US10Y",
          price: byId.us10y?.price ?? 0,
          changePct: byId.us10y?.changePct ?? 0,
          unit: "%",
          effect: byId.us10y?.price ? effectLine(factorScore("yield")) : "thiếu dữ liệu",
        },
        {
          id: "vix",
          label: "VIX",
          price: byId.vix?.price ?? 0,
          changePct: byId.vix?.changePct ?? 0,
          unit: "",
          effect: byId.vix?.price ? effectLine(factorScore("vix")) : "thiếu dữ liệu",
        },
        {
          id: "gld",
          label: "GLD",
          price: byId.gld?.price ?? 0,
          changePct: byId.gld?.changePct ?? 0,
          unit: "USD",
          effect: byId.gld?.price ? "giá ETF, không phải dòng tiền" : "thiếu dữ liệu",
        },
        {
          id: "silver",
          label: "Bạc",
          price: byId.silver?.price ?? 0,
          changePct: byId.silver?.changePct ?? 0,
          unit: "USD/oz",
          effect: byId.silver?.price ? effectLine(factorScore("gs")) : "thiếu dữ liệu",
        },
      ];

      const series = gold.bars.slice(-90).map((b) => ({ label: dayLabel(b.t), close: Number(b.c.toFixed(2)) }));
      const asOf = new Date((gold.time ?? Math.floor(Date.now() / 1000)) * 1000).toISOString();
      const tech = buildTech(m5[0] ?? [], h1[0] ?? []);
      const desk: DeskOk = {
        ok: true,
        asOf,
        quotes: quoteDefs.filter((q) => q.price > 0).map(({ effect, ...q }) => ({ ...q, goldEffect: effect })),
        goldSeries: series,
        factors: model.factors,
        composite: model.composite,
        dailyVol: model.dailyVol,
        price: model.price,
        quantNote: model.quantNote,
        news: topNews,
        flows: extractFlows(topNews),
        caveats: CAVEATS,
        tech,
      };
      cache = { at: Date.now(), data: desk };
      return desk;
    } catch (err) {
      console.error("[aurum] desk fetch failed", err);
      if (cache) return cache.data;
      return { ok: false, error: "Không gom được dữ liệu thị trường. Thử lại." };
    }
  });
