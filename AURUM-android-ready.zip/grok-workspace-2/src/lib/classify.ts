import { clamp } from "@/lib/format";
import type { FlowSignal, Lean, NewsItem } from "@/lib/types";

type Rule = {
  re: RegExp;
  side: 1 | -1;
  w: number;
  tag: string;
  why: string;
};

const RULES: Rule[] = [
  {
    re: /rate cut|cuts rates|dovish|pivot/i,
    side: 1,
    w: 0.65,
    tag: "fed",
    why: "kỳ vọng lãi suất hạ làm giảm chi phí cơ hội của vàng",
  },
  {
    re: /rate hike|hawkish|higher for longer/i,
    side: -1,
    w: 0.7,
    tag: "fed",
    why: "giọng thắt chặt giữ lợi suất cao, vàng bị trái phiếu cạnh tranh",
  },
  {
    re: /yields? (fall|drop|slid|ease|tumble|decline)|falling yields/i,
    side: 1,
    w: 0.7,
    tag: "lợi suất",
    why: "lợi suất giảm thường nâng vàng",
  },
  {
    re: /yields? (rise|rose|jump|climb|surge|soar)|higher yields|yields? hit/i,
    side: -1,
    w: 0.72,
    tag: "lợi suất",
    why: "lợi suất tăng là lực cản cổ điển với vàng",
  },
  {
    re: /dollar (weak|falls|slides|drops|sinks)|dxy (falls|drops|weak|slid)/i,
    side: 1,
    w: 0.55,
    tag: "usd",
    why: "USD yếu làm vàng rẻ hơn với người mua ngoại tệ",
  },
  {
    re: /dollar (strength|strong|rall|gains|surges)|dxy (up|rall|gains|strength)/i,
    side: -1,
    w: 0.55,
    tag: "usd",
    why: "USD mạnh thường đè giá vàng niêm yết bằng đô",
  },
  {
    re: /central banks?.{0,48}(buy|buying|bought|purchase|add|boost)/i,
    side: 1,
    w: 0.8,
    tag: "dòng tiền",
    why: "mua của ngân hàng trung ương là cầu vật chất, ít nhạy với giá ngắn hạn",
  },
  {
    re: /(buy|buying|bought|purchase|adds|added|boosts).{0,48}(gold reserves|bullion|tonnes|tons)/i,
    side: 1,
    w: 0.75,
    tag: "dòng tiền",
    why: "tiêu đề nói tới mua vàng vật chất",
  },
  {
    re: /central banks?.{0,48}(sell|selling|sold|cut reserves|reduce)/i,
    side: -1,
    w: 0.8,
    tag: "dòng tiền",
    why: "bán từ khu vực chính thức là cung lớn",
  },
  {
    re: /(sell|selling|sold|dump).{0,40}(gold reserves|bullion|tonnes|tons)/i,
    side: -1,
    w: 0.7,
    tag: "dòng tiền",
    why: "tiêu đề nói tới bán vàng vật chất",
  },
  {
    re: /etf inflow|inflows into|holdings (rise|rose|climb)|added (to )?holdings/i,
    side: 1,
    w: 0.6,
    tag: "dòng tiền",
    why: "dòng vào ETF vàng là cầu giấy",
  },
  {
    re: /etf outflow|outflows|holdings (fall|fell|drop|decline)/i,
    side: -1,
    w: 0.6,
    tag: "dòng tiền",
    why: "rút vốn ETF là lực bán giấy",
  },
  {
    re: /war|missile|airstrike|invasion|escalat|sanction|troops|conflict/i,
    side: 1,
    w: 0.48,
    tag: "chiến sự",
    why: "rủi ro địa chính trị thường kéo cầu trú ẩn, nhưng không phải lúc nào cũng thắng lợi suất",
  },
  {
    re: /ceasefire|peace deal|truce|de-escalat|deescalat/i,
    side: -1,
    w: 0.45,
    tag: "hạ nhiệt",
    why: "hạ nhiệt địa chính trị gỡ một phần phần bù rủi ro của vàng",
  },
  {
    re: /tariff|trade war|election|geopolit/i,
    side: 1,
    w: 0.3,
    tag: "chính trị",
    why: "bất định chính sách có thể tăng nhu cầu trú ẩn",
  },
  {
    re: /inflation (hot|rise|jump|surge|above)|cpi (hot|above|beat|surprise)/i,
    side: 1,
    w: 0.4,
    tag: "lạm phát",
    why: "lạm phát cao giữ vai trò bảo toàn sức mua, trừ khi nó kéo lãi suất thực lên",
  },
  {
    re: /recession|hard landing|slowdown/i,
    side: 1,
    w: 0.28,
    tag: "fed",
    why: "suy giảm tăng trưởng nghiêng về nới lỏng sau đó — hỗ trợ có điều kiện",
  },
  {
    re: /cuts?.{0,40}target|lowers?.{0,24}(gold )?forecast|bearish on gold/i,
    side: -1,
    w: 0.35,
    tag: "giá",
    why: "một tổ chức hạ dự báo — ý kiến, không phải dòng tiền",
  },
  {
    re: /raises?.{0,40}target|lifts?.{0,24}(gold )?forecast|bullish on gold/i,
    side: 1,
    w: 0.3,
    tag: "giá",
    why: "một tổ chức nâng dự báo — ý kiến, không phải dòng tiền",
  },
  {
    re: /gold (slump|tumbles|drops|falls|slides|sinks|slips|weakens|selloff|sell-off|plunges)|bullion (falls|drops|slides)/i,
    side: -1,
    w: 0.22,
    tag: "giá",
    why: "tin đang mô tả đà giảm — đó là mô tả giá, chưa phải nguyên nhân mới",
  },
  {
    re: /gold (record|all-time|soars|surges|jumps|rallies)|bullion (hits record|rises)/i,
    side: 1,
    w: 0.2,
    tag: "giá",
    why: "tin đang mô tả đà tăng — mô tả giá, chưa phải cú sốc mới",
  },
  {
    re: /lao dốc|giảm sâu|giảm mạnh|tuột khỏi|điều chỉnh khốc liệt|tiếp tục giảm|giảm liên tục|tuần giảm/i,
    side: -1,
    w: 0.28,
    tag: "giá",
    why: "báo đang mô tả đà giảm của vàng — đó là mô tả giá, chưa phải nguyên nhân mới",
  },
  {
    re: /lợi suất tăng|đô la mạnh|usd mạnh|thắt chặt/i,
    side: -1,
    w: 0.55,
    tag: "lợi suất",
    why: "lợi suất hoặc đô la được nêu là lực cản của vàng",
  },
  {
    re: /ngân hàng trung ương.{0,40}(mua|gom)|gom vàng|tăng dự trữ vàng/i,
    side: 1,
    w: 0.75,
    tag: "dòng tiền",
    why: "bài nói tới mua vàng của khu vực chính thức",
  },
  {
    re: /chiến sự|địa chính trị|căng thẳng địa chính trị|trừng phạt/i,
    side: 1,
    w: 0.4,
    tag: "chiến sự",
    why: "bất định chính trị thường kéo cầu trú ẩn, nhưng không chắc thắng lợi suất",
  },
  {
    re: /(?<!khó )(?<!chưa )(?<!không )phục hồi|tăng mạnh|lập đỉnh|vượt đỉnh/i,
    side: 1,
    w: 0.22,
    tag: "giá",
    why: "bài đang mô tả đà tăng hoặc nhịp hồi",
  },
];

const STRONG =
  /(gold price|spot gold|gold futures|bullion|xauusd|xau\/usd|\bxau\b|comex gold|gold etf|spdr gold|gold reserves|giá vàng|vàng thế giới|usd\/oz|per ounce|\/oz|kim loại quý)/i;
const WEAK = /\bgold\b|vàng/i;
const CONTEXT =
  /(price|futures|bullion|etf|central bank|fed\b|yield|dollar|inflation|reserve|tonne|tonnes|ounce|comex|pboc|safe haven|ngân hàng|lợi suất|đô la)/i;

export function isGoldNews(title: string) {
  if (/chart image|tradingview/i.test(title)) return false;
  if (STRONG.test(title)) return true;
  return WEAK.test(title) && CONTEXT.test(title);
}

function hash(title: string) {
  let h = 0;
  for (let i = 0; i < title.length; i++) h = (h * 31 + title.charCodeAt(i)) >>> 0;
  return h.toString(16);
}

export function classifyHeadline(title: string): Pick<NewsItem, "lean" | "score" | "tags" | "note"> {
  let bull = 0;
  let bear = 0;
  const tags = new Set<string>();
  const whys: string[] = [];
  for (const rule of RULES) {
    if (!rule.re.test(title)) continue;
    tags.add(rule.tag);
    if (rule.side > 0) bull = Math.max(bull, rule.w);
    else bear = Math.max(bear, rule.w);
    whys.push(rule.why);
  }
  let score = clamp(bull - bear, -1, 1);
  let lean: Lean = "quiet";
  if (bull > 0.35 && bear > 0.35) {
    lean = "mixed";
    score = clamp(score, -0.35, 0.35);
  } else if (score > 0.15) lean = "bullish";
  else if (score < -0.15) lean = "bearish";

  const strength = Math.abs(score) > 0.55 ? "lớn" : Math.abs(score) > 0.3 ? "vừa" : "nhỏ";
  const why = whys[0] ?? "không đủ chữ để gán nguyên nhân";
  let note: string;
  if (lean === "quiet") {
    note = "Tiêu đề không đủ chữ để chấm hướng. Giữ trung tính cho đến khi đọc nội dung.";
  } else if (lean === "mixed") {
    note = `Hai lực ngược nhau trong cùng tiêu đề. ${why}. Suy luận từ chữ, chưa phải sự kiện đã kiểm.`;
  } else if (lean === "bullish") {
    note = `Nghiêng hỗ trợ vàng, cường độ ${strength}: ${why}. Suy luận từ tiêu đề.`;
  } else {
    note = `Nghiêng áp lực lên vàng, cường độ ${strength}: ${why}. Suy luận từ tiêu đề.`;
  }
  return { lean, score, tags: [...tags], note };
}

export function toNewsItem(input: {
  title: string;
  link: string;
  source: string;
  publishedAt: string;
  lang: "vi" | "en";
}): NewsItem | null {
  const title = input.title.replace(/\s+/g, " ").trim();
  if (!title || !isGoldNews(title)) return null;
  if (!/^https?:\/\//i.test(input.link)) return null;
  const classified = classifyHeadline(title);
  return {
    id: hash(title.toLowerCase()),
    title,
    link: input.link,
    source: input.source || "Nguồn tin",
    publishedAt: input.publishedAt,
    lang: input.lang,
    ...classified,
  };
}

export type ActorDef = {
  id: string;
  name: string;
  role: string;
  patterns: RegExp[];
};

export const ACTORS: ActorDef[] = [
  {
    id: "pboc",
    name: "PBOC — Trung Quốc",
    role: "Nhà mua cấu trúc của khối chính thức nhiều năm. Chỉ kết luận thu hoặc bán khi tiêu đề hoặc sổ tay của bạn có nguồn.",
    patterns: [/pboc|people's bank of china|china gold reserves|chinese (central bank|gold)/i],
  },
  {
    id: "nbp",
    name: "NBP — Ba Lan",
    role: "Ngân hàng trung ương Ba Lan từng mua lớn theo báo cáo chính thức. Không suy ra tuần này nếu tin không nhắc.",
    patterns: [/\bnbp\b|narodowy bank|polish central|poland'?s gold/i],
  },
  {
    id: "rbi",
    name: "RBI — Ấn Độ",
    role: "Ngân hàng Dự trữ Ấn Độ. Cầu trang sức Ấn Độ là kênh khác, đừng gộp với dự trữ chính thức.",
    patterns: [/\brbi\b|reserve bank of india|india'?s gold reserves/i],
  },
  {
    id: "cbrt",
    name: "CBRT — Thổ Nhĩ Kỳ",
    role: "Có giai đoạn bán vàng nội địa để bình ổn rồi mua lại. Chiều giao dịch đổi theo năm — không gán một chiều vĩnh viễn.",
    patterns: [/cbrt|turkish central|turkey gold reserves|tcmb/i],
  },
  {
    id: "cbr",
    name: "Ngân hàng Nga",
    role: "Dự trữ vàng là công cụ bị theo dõi vì trừng phạt. Số liệu thường trễ và khó kiểm.",
    patterns: [/bank of russia|russian central bank|russia'?s gold/i],
  },
  {
    id: "gld",
    name: "SPDR Gold (GLD)",
    role: "ETF lớn nhất. Muốn biết thu hay bán cần ounces outstanding, không phải giá cổ phiếu.",
    patterns: [/\bgld\b|spdr gold/i],
  },
  {
    id: "iau",
    name: "iShares Gold (IAU)",
    role: "ETF vật chất thứ hai tại Mỹ. Cùng logic holdings, không nhìn giá.",
    patterns: [/\biau\b|ishares gold/i],
  },
  {
    id: "comex",
    name: "Kho COMEX",
    role: "Tồn kho registered giảm không tự động bằng 'ai đó gom vàng'. Có thể là chuyển kho hoặc đứng vị thế.",
    patterns: [/comex/i],
  },
  {
    id: "etf",
    name: "ETF vàng (chung)",
    role: "Dòng ETF toàn cầu là cầu giấy nhanh nhất. Tách khỏi mua của ngân hàng trung ương.",
    patterns: [/gold etf|bullion etf|etf inflow|etf outflow/i],
  },
  {
    id: "mm",
    name: "Managed money / COT",
    role: "Vị thế đầu cơ trên COMEX (báo cáo CFTC thứ Sáu). Chưa có file COT trong app — chỉ hiện khi tin nhắc.",
    patterns: [/managed money|hedge fund|cftc|cot report|speculators/i],
  },
  {
    id: "cb",
    name: "Ngân hàng trung ương (chung)",
    role: "Khi tin nói 'central banks' mà không nêu tên, không gán cho một nước.",
    patterns: [/central banks?/i],
  },
];

function flowSide(title: string): "thu" | "bán" | "không rõ" {
  const buy = /(buy|buying|bought|purchase|accumul|inflow|adds reserves|boosts reserves|tăng dự trữ|mua vào|gom vàng)/i.test(
    title,
  );
  const sell = /(sell|selling|sold|outflow|dump|cut reserves|reduce reserves|bán ra|xả vàng)/i.test(title);
  if (buy && !sell) return "thu";
  if (sell && !buy) return "bán";
  return "không rõ";
}

function flowSize(title: string) {
  const m = title.match(/(\d[\d,.]*)\s*(tonnes|tons|metric tons|tấn)/i);
  if (m) return `${m[1]} ${m[2]} — theo tiêu đề, chưa đối chiếu thông cáo`;
  if (/record|largest|massive|heavy|lượng lớn/i.test(title)) return "bài viết gọi là lớn, không có số";
  return "không nêu quy mô";
}

export function extractFlows(items: NewsItem[]): FlowSignal[] {
  const merged = new Map<string, FlowSignal>();
  for (const item of items) {
    const specific = ACTORS.filter((a) => a.id !== "cb" && a.patterns.some((p) => p.test(item.title)));
    const matched = specific.length
      ? specific
      : ACTORS.filter((a) => a.id === "cb" && a.patterns.some((p) => p.test(item.title)));
    for (const actor of matched) {
      const side = flowSide(item.title);
      const tonnes = /tonne|tonnes|tons|tấn/i.test(item.title);
      let confidence = side === "không rõ" ? 22 : 46;
      if (tonnes) confidence += 24;
      if (/record|largest|lượng lớn/i.test(item.title)) confidence += 8;
      confidence = Math.min(confidence, 88);
      const key = `${actor.id}:${side}`;
      const prev = merged.get(key);
      const evidence =
        side === "không rõ"
          ? `Được nhắc, chưa đủ chữ để kết luận thu hay bán: ${item.title}`
          : item.title;
      if (!prev || confidence > prev.confidence) {
        merged.set(key, {
          actorId: actor.id,
          actor: actor.name,
          side,
          size: flowSize(item.title),
          evidence,
          confidence,
          sourceTitle: item.title,
        });
      }
    }
  }
  return [...merged.values()].sort((a, b) => b.confidence - a.confidence);
}

export function newsAggregates(items: NewsItem[]) {
  const scored = items.filter((i) => i.lean !== "quiet");
  const newsScore = scored.length ? clamp(mean(scored.map((i) => i.score)), -1, 1) : 0;
  const geoItems = items.filter((i) => i.tags.includes("chiến sự") || i.tags.includes("chính trị"));
  const deesc = items.filter((i) => i.tags.includes("hạ nhiệt")).length;
  const flowMentions = items.filter((i) => i.tags.includes("dòng tiền")).length;
  return {
    newsScore,
    newsCount: items.length,
    geoHeat: items.length ? geoItems.length / items.length : 0,
    geoCount: geoItems.length,
    deescalation: items.length ? deesc / items.length : 0,
    flowMentions,
  };
}

function mean(xs: number[]) {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}
