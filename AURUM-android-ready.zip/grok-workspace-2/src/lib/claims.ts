import type { NewsItem, SourceCall } from "@/lib/types";

const FORECAST =
  /forecast|predicts?|prediction|expects?|outlook|price target|could (?:hit|reach|fall|rise|test)|likely to (?:rise|fall|hit|test)|will (?:rise|fall|hit|reach)|upside to|downside to|sees gold|gold (?:to hit|will reach|could)|dự báo|dự đoán|kỳ vọng|mục tiêu|nhận định|triển vọng|có thể (?:lên|xuống|chạm|về)|sẽ (?:tăng|giảm|vượt|phá|chạm)|hướng tới/i;

export const CURRENT_WINDOW_MS = 36 * 60 * 60 * 1000;

export function isForecast(title: string) {
  return FORECAST.test(title);
}

export function sourceCalls(news: NewsItem[]): SourceCall[] {
  return news.flatMap((item) => {
    if (!isForecast(item.title)) return [];
    return [
      {
        id: item.id,
        claim: item.title,
        source: item.source || "không rõ nguồn",
        publishedAt: item.publishedAt,
        link: item.link,
      },
    ];
  });
}

export function splitByAge(news: NewsItem[], now = Date.now()) {
  const current: NewsItem[] = [];
  const older: NewsItem[] = [];
  for (const item of news) {
    const at = Date.parse(item.publishedAt);
    if (Number.isFinite(at) && now - at <= CURRENT_WINDOW_MS && now - at >= 0) current.push(item);
    else older.push(item);
  }
  return { current, older };
}

function words(title: string) {
  return new Set(
    title
      .toLowerCase()
      .normalize("NFD")
      .replace(/\p{M}/gu, "")
      .split(/[^a-z0-9]+/)
      .filter((word) => word.length > 4),
  );
}

export function relatedNews(item: NewsItem, list: NewsItem[]) {
  const tags = new Set(item.tags);
  const bag = words(item.title);
  return list.filter((other) => {
    if (other.id === item.id) return false;
    if (other.tags.some((tag) => tags.has(tag))) return true;
    let share = 0;
    for (const word of words(other.title)) if (bag.has(word)) share += 1;
    return share >= 2;
  });
}
