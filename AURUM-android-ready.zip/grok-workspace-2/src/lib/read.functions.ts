import { createServerFn } from "@tanstack/react-start";
import type { AiRead } from "@/lib/types";

type ReadInput = {
  title: string;
  source: string;
  note: string;
  publishedAt: string;
  current: { title: string; source: string; publishedAt: string }[];
  older: { title: string; source: string; publishedAt: string }[];
  calls: { source: string; claim: string }[];
  tech: string;
  risks: string;
  vtun: string;
};

let lastCall = 0;

function str(value: unknown, max: number) {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

function asRecord(value: unknown) {
  if (!value || typeof value !== "object") return null;
  return value as Record<string, unknown>;
}

function lines(value: unknown, max: number) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, max).flatMap((item) => {
    const row = asRecord(item);
    const title = str(row?.title, 180);
    const source = str(row?.source, 80);
    if (!title) return [];
    return [{ title, source: source || "không rõ nguồn", publishedAt: str(row?.publishedAt, 40) }];
  });
}

export const readNews = createServerFn({ method: "POST" })
  .validator((input: unknown): ReadInput => {
    const row = asRecord(input);
    if (!row) throw new Error("Thiếu tin.");
    const title = str(row.title, 180);
    if (!title) throw new Error("Thiếu tiêu đề.");
    const calls = Array.isArray(row.calls)
      ? row.calls.slice(0, 8).flatMap((item) => {
          const call = asRecord(item);
          const claim = str(call?.claim, 180);
          if (!claim) return [];
          return [{ source: str(call?.source, 80) || "không rõ nguồn", claim }];
        })
      : [];
    return {
      title,
      source: str(row.source, 80),
      note: str(row.note, 240),
      publishedAt: str(row.publishedAt, 40),
      current: lines(row.current, 6),
      older: lines(row.older, 6),
      calls,
      tech: str(row.tech, 1800),
      risks: str(row.risks, 800),
      vtun: str(row.vtun, 500),
    };
  })
  .handler(async ({ data }): Promise<{ ok: true; read: AiRead } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false, error: "Dự đoán AI chưa bật. Dự đoán của VTUN phía trên vẫn dùng được." };
    }
    const now = Date.now();
    if (now - lastCall < 8_000) return { ok: false, error: "Đợi vài giây rồi đọc lại. Mỗi lần AI tốn một lượt." };
    lastCall = now;

    const block = (items: ReadInput["current"]) =>
      items.length ? items.map((item) => `- ${item.publishedAt || "không rõ giờ"} · ${item.source}: ${item.title}`).join("\n") : "- Không có.";
    const callBlock = data.calls.length
      ? data.calls.map((item) => `- ${item.source}: ${item.claim}`).join("\n")
      : "- Không có tiêu đề nào là dự đoán.";

    const userPrompt = `Giờ bàn là GMT+7. Chỉ dùng dữ liệu dưới đây.
Tin đang đọc (${data.publishedAt || "không rõ giờ"} GMT+7, nguồn ${data.source || "không rõ"}): ${data.title}
Ghi chú máy: ${data.note || "không có"}

Tin hiện (36 giờ):
${block(data.current)}

Tin cũ (trước đó, trong 7 ngày):
${block(data.older)}

Dự đoán đã thấy từ nguồn khác — nếu nhắc lại phải giữ đúng tên nguồn:
${callBlock}

Kỹ thuật đã đo (VP WEEK, VP DAY, VWAP, CVD/OBV trên M5 và H1). Không bịa mức giá khác:
${data.tech || "không có"}

Cảnh báo máy:
${data.risks || "không có"}

Dự đoán VTUN (đừng ký tên VTUN, đừng nhận phần này là của AI):
${data.vtun || "không có"}

Trả JSON. Tiếng Việt, câu ngắn.`;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        signal: AbortSignal.timeout(45_000),
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.2,
          max_tokens: 900,
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content:
                "Bạn là lớp dự đoán AI của bàn AURUM, không phải VTUN. VTUN đã có dự đoán và lý do riêng. Bạn không ký VTUN. Khi nêu nhận định của người khác, chỉ dùng nguồn có trong danh sách được cấp — không bịa nguồn, không bịa mức giá ngoài bảng kỹ thuật. Nếu cảnh báo ghi rủi ro cao, phải nhắc lại, không xoa dịu. Giờ là GMT+7. Không phải khuyến nghị đầu tư. Chỉ trả JSON với khóa: now (tin hiện đang nói gì), past (tin cũ khác gì), cited (mảng {source, claim} — rỗng nếu không có dự đoán của người khác), prediction (dự đoán của AI, một đoạn), bias (bullish|bearish|neutral), risks (mảng chuỗi cảnh báo).",
            },
            { role: "user", content: userPrompt },
          ],
        }),
      });
      if (!res.ok) return { ok: false, error: `AI không đọc được tin (mã ${res.status}).` };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const read = normalize(parseJson(body.choices?.[0]?.message?.content ?? ""), data.calls.map((c) => c.source));
      return { ok: true, read };
    } catch (err) {
      console.error("[aurum] read news failed", err);
      return { ok: false, error: "AI lỗi hoặc quá giờ. Chạy lại một lần." };
    }
  });

function parseJson(text: string): unknown {
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new Error("parse");
  }
}

function normalize(raw: unknown, allowed: string[]): AiRead {
  const row = asRecord(raw);
  if (!row) throw new Error("parse");
  const bias = row.bias === "bullish" || row.bias === "bearish" || row.bias === "neutral" ? row.bias : "neutral";
  const known = new Set(allowed.map((s) => s.toLowerCase()));
  const cited = (Array.isArray(row.cited) ? row.cited : []).slice(0, 6).flatMap((item) => {
    const cite = asRecord(item);
    const source = str(cite?.source, 80);
    const claim = str(cite?.claim, 220);
    if (!source || !claim || !known.size) return [];
    const sourceOk = [...known].some((name) => name === source.toLowerCase() || name.includes(source.toLowerCase()) || source.toLowerCase().includes(name));
    if (!sourceOk) return [];
    return [{ source, claim }];
  });
  const risks = (Array.isArray(row.risks) ? row.risks : []).slice(0, 4).map((item) => str(item, 240)).filter(Boolean);
  return {
    now: str(row.now, 500),
    past: str(row.past, 500),
    cited,
    prediction: str(row.prediction, 700),
    bias,
    risks,
  };
}
