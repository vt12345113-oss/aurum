import { clamp } from "@/lib/format";
import type { Factor, Horizon, Scenario } from "@/lib/types";

export const HORIZON_DAYS: Record<Horizon, number> = { "1d": 1, "5d": 5, "3m": 63 };

export const HORIZON_LABEL: Record<Horizon, string> = {
  "1d": "1 phiên",
  "5d": "5 phiên",
  "3m": "1–3 tháng",
};

export function mean(xs: number[]) {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

export function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  const v = xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1);
  return Math.sqrt(v);
}

export function ret(closes: number[], n: number): number | null {
  if (closes.length <= n) return null;
  const last = closes[closes.length - 1];
  const prev = closes[closes.length - 1 - n];
  if (last == null || prev == null || prev === 0) return null;
  return (last - prev) / prev;
}

export function dailyVol(closes: number[]): number | null {
  if (closes.length < 22) return null;
  const rets: number[] = [];
  for (let i = closes.length - 20; i < closes.length; i++) {
    const a = closes[i - 1];
    const b = closes[i];
    if (a == null || b == null || a === 0) continue;
    rets.push((b - a) / a);
  }
  if (rets.length < 10) return null;
  return stdev(rets);
}

function unitZ(series: number[]): number | null {
  if (series.length < 20) return null;
  const last = series[series.length - 1];
  if (last == null) return null;
  const m = mean(series);
  const s = stdev(series);
  if (!s) return 0;
  return clamp((last - m) / s / 2, -1, 1);
}

function pct(n: number | null, digits = 1) {
  if (n == null || !Number.isFinite(n)) return "thiếu";
  const sign = n > 0 ? "+" : "";
  return `${sign}${(n * 100).toFixed(digits)}%`;
}

function pp(n: number | null) {
  if (n == null || !Number.isFinite(n)) return "thiếu";
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(2)} điểm %`;
}

export type ModelInput = {
  gold: number[];
  dxy: number[];
  yld: number[];
  vix: number[];
  gld: number[];
  silver: number[];
  newsScore: number;
  newsCount: number;
  geoHeat: number;
  geoCount: number;
  deescalation: number;
  flowMentions: number;
};

export type ModelOutput = {
  price: number;
  composite: number;
  dailyVol: number;
  factors: Factor[];
  quantNote: string;
};

function push(
  factors: Factor[],
  factor: Factor,
) {
  factors.push(factor);
}

export function buildModel(input: ModelInput): ModelOutput | null {
  const { gold, dxy, yld, vix, gld, silver } = input;
  if (gold.length < 30) return null;
  const price = gold[gold.length - 1];
  if (price == null || price <= 0) return null;
  const vol = dailyVol(gold) ?? 0.01;
  const ret1 = ret(gold, 1);
  const ret5 = ret(gold, 5);
  const ret20 = ret(gold, 20);
  const ret60 = ret(gold, 60);

  const factors: Factor[] = [];

  const geoScore = clamp(input.geoHeat * 1.1 - input.deescalation * 0.9, -1, 1);
  push(factors, {
    id: "geo",
    group: "politics",
    name: "Nhiệt địa chính trị",
    score: input.newsCount ? geoScore : 0,
    weight: 0.1,
    reading: input.newsCount
      ? `${input.geoCount} tin chiến sự/chính trị trên ${input.newsCount} tiêu đề 7 ngày. Hạ nhiệt: ${(input.deescalation * 100).toFixed(0)}% tin.`
      : "Không có tin để đo nhiệt chính trị.",
    mechanism:
      "Chiến sự, trừng phạt, thuế quan thường kéo cầu trú ẩn. Thỏa ngừng bắn gỡ phần bù đó. Lợi suất vẫn có thể thắng lực này.",
    evidence: "inferred",
  });

  push(factors, {
    id: "institution",
    group: "politics",
    name: "Niềm tin thể chế và USD",
    score: clamp(0.15 + (input.flowMentions > 0 ? 0.15 : 0) + input.geoHeat * 0.25, -1, 1) * 0.5,
    weight: 0.05,
    reading:
      "Nền nhiều năm: dự trữ chính thức dịch từ USD sang vàng khi trừng phạt và đóng băng tài sản là công cụ chính trị. Không có số tấn tuần này.",
    mechanism:
      "Đây là cầu chậm, không giải thích một phiên. Chỉ nâng đáy dài hạn, không phải tín hiệu vào lệnh.",
    evidence: "structural",
  });

  const yLast = yld[yld.length - 1];
  const yPrev = yld.length > 20 ? yld[yld.length - 21] : null;
  const dy = yLast != null && yPrev != null ? yLast - yPrev : null;
  const yZ = unitZ(yld);
  const chgScore = dy == null ? 0 : clamp(dy / 0.35, -1, 1);
  const yieldScore =
    yld.length < 25 || yZ == null ? 0 : clamp(-(0.45 * yZ + 0.55 * chgScore), -1, 1);
  push(factors, {
    id: "yield",
    group: "macro",
    name: "Lợi suất 10 năm Mỹ",
    score: yieldScore,
    weight: 0.22,
    reading:
      yLast == null
        ? "Thiếu lợi suất."
        : `US10Y ${yLast.toFixed(2)}%. 20 phiên: ${pp(dy)}. So với 6 tháng: ${yZ == null ? "thiếu" : yZ > 0.25 ? "đang ở vùng cao" : yZ < -0.25 ? "đang ở vùng thấp" : "gần trung bình"}.`,
    mechanism:
      "Vàng không trả lãi. Lợi suất danh nghĩa cao — khi lạm phát không tăng cùng nhịp — là chi phí cơ hội. App không có TIPS, nên đây là proxy, không phải lợi suất thực.",
    evidence: "measured",
  });

  const dxy20 = ret(dxy, 20);
  const dxy5 = ret(dxy, 5);
  const dxyLast = dxy[dxy.length - 1];
  const dollarScore =
    dxy.length < 25
      ? 0
      : clamp(
          -(0.7 * Math.tanh((dxy20 ?? 0) / 0.02) + 0.3 * Math.tanh((dxy5 ?? 0) / 0.008)),
          -1,
          1,
        );
  push(factors, {
    id: "dollar",
    group: "macro",
    name: "Đô la (DXY)",
    score: dollarScore,
    weight: 0.14,
    reading:
      dxyLast == null
        ? "Thiếu DXY."
        : `DXY ${dxyLast.toFixed(2)}. 5 phiên ${pct(dxy5)}, 20 phiên ${pct(dxy20)}.`,
    mechanism: "XAUUSD niêm yết bằng đô. Đô mạnh lên thường đè giá, đô yếu thì ngược lại — trừ khi cú sốc trú ẩn nâng cả hai.",
    evidence: "measured",
  });

  const vixLast = vix[vix.length - 1];
  const vixPrev = vix.length > 5 ? vix[vix.length - 6] : null;
  let vixScore = 0;
  if (vixLast != null) {
    if (vixLast < 14) vixScore = -0.3;
    else if (vixLast < 20) vixScore = (vixLast - 16) / 20;
    else if (vixLast < 28) vixScore = 0.35 + (vixLast - 20) / 40;
    else vixScore = 0.1;
    if (vixPrev != null) vixScore += clamp((vixLast - vixPrev) / 8, -0.25, 0.25);
  }
  vixScore = clamp(vixScore, -1, 1);
  push(factors, {
    id: "vix",
    group: "macro",
    name: "Biến động cổ phiếu (VIX)",
    score: vix.length < 10 ? 0 : vixScore,
    weight: 0.08,
    reading:
      vixLast == null
        ? "Thiếu VIX."
        : `VIX ${vixLast.toFixed(1)}${vixPrev != null ? `, 5 phiên trước ${vixPrev.toFixed(1)}` : ""}.`,
    mechanism:
      "VIX vừa phải và tăng thường đi với cầu trú ẩn. VIX cực cao có thể là phiên gọi ký quỹ — vàng bị bán theo để lấy tiền, nên điểm không tăng tuyến tính.",
    evidence: "measured",
  });

  const trend = Math.tanh((ret20 ?? 0) / 0.045);
  const stretch = ret5 != null && ret5 < -0.025 ? 0.18 : ret5 != null && ret5 > 0.025 ? -0.12 : 0;
  const momentum = gold.length < 25 ? 0 : clamp(trend * 0.85 + stretch, -1, 1);
  push(factors, {
    id: "momentum",
    group: "quant",
    name: "Momentum và quá đà",
    score: momentum,
    weight: 0.16,
    reading: `1 phiên ${pct(ret1)}, 5 phiên ${pct(ret5)}, 20 phiên ${pct(ret20)}, 60 phiên ${pct(ret60)}. Vol 20 phiên ${(vol * 100).toFixed(2)}%/ngày.`,
    mechanism:
      "Xu hướng 20 phiên được theo. Một cú rơi hoặc tăng cực đoan trong 5 phiên được bù nhẹ theo hướng trung bình — không phải tín hiệu đảo chiều chắc.",
    evidence: "measured",
  });

  const gld5 = ret(gld, 5);
  const gldLast = gld[gld.length - 1];
  push(factors, {
    id: "gld",
    group: "flow",
    name: "Giá GLD (proxy tham gia)",
    score: gld.length < 10 ? 0 : clamp(Math.tanh((gld5 ?? 0) / 0.02), -1, 1),
    weight: 0.07,
    reading:
      gldLast == null
        ? "Thiếu GLD."
        : `GLD ${gldLast.toFixed(2)} USD. 5 phiên ${pct(gld5)}. Đây là giá chứng chỉ, không phải tấn vàng chảy vào ETF.`,
    mechanism:
      "ETF thực sự cần số dư holdings (GLD ounces). Khi chưa có số đó, giá GLD chỉ cho biết đà tham gia cùng chiều với vàng, dễ trùng với momentum.",
    evidence: "measured",
  });

  const silLast = silver[silver.length - 1];
  const ratioNow = silLast ? price / silLast : null;
  const ratioThen =
    silver.length > 21 && gold.length > 21 && silver[silver.length - 21]
      ? gold[gold.length - 21]! / silver[silver.length - 21]!
      : null;
  const ratioRet = ratioNow && ratioThen ? ratioNow / ratioThen - 1 : null;
  push(factors, {
    id: "gs",
    group: "quant",
    name: "Tỷ lệ vàng/bạc",
    score: ratioRet == null ? 0 : clamp(Math.tanh(ratioRet / 0.04), -1, 1),
    weight: 0.04,
    reading:
      ratioNow == null
        ? "Thiếu bạc."
        : `Vàng/bạc ${ratioNow.toFixed(1)}. 20 phiên ${pct(ratioRet)}.`,
    mechanism:
      "Tỷ lệ tăng nghĩa là vàng chạy hơn bạc — thường là phiên phòng thủ. Tỷ lệ giảm nghiêng reflation, vàng vẫn có thể tăng nhưng kém chất 'trú ẩn'.",
    evidence: "measured",
  });

  const newsFactor = input.newsCount >= 3 ? clamp(input.newsScore, -1, 1) : 0;
  push(factors, {
    id: "news",
    group: "politics",
    name: "Điểm tin 7 ngày",
    score: newsFactor,
    weight: 0.14,
    reading:
      input.newsCount < 3
        ? `Chỉ ${input.newsCount} tiêu đề liên quan — không đưa vào điểm tổng.`
        : `Điểm tiêu đề ${(newsFactor * 100).toFixed(0)} trên thang −100…+100. ${input.newsCount} tin sau khi lọc.`,
    mechanism:
      "Chỉ đọc tiêu đề, chấm bằng từ khóa. Không phải xác suất đã kiểm chứng. Một tin sai nguồn có thể làm lệch mục này, nên trọng số không vượt lợi suất.",
    evidence: "inferred",
  });

  push(factors, {
    id: "official",
    group: "flow",
    name: "Cầu chính thức nhiều năm",
    score: 0.45,
    weight: 0.05,
    reading: "Tiên nghiệm dương nhỏ. Không gắn với nước nào, không gắn với tuần này.",
    mechanism:
      "Từ 2022 khu vực chính thức là bên mua ròng cấu trúc. Muốn biết tuần này ai thu hay bán, xem sổ dòng tiền — ô trống nghĩa là chưa có nguồn.",
    evidence: "structural",
  });

  const weightSum = factors.reduce((a, f) => a + f.weight, 0) || 1;
  const composite = clamp(
    factors.reduce((a, f) => a + f.score * f.weight, 0) / weightSum,
    -1,
    1,
  );

  const notes: string[] = [];
  if (ret5 != null && ret5 <= -0.02) {
    notes.push(`Vàng giảm ${(Math.abs(ret5) * 100).toFixed(1)}% trong 5 phiên — momentum ngắn đang là lực bán, có một phần bù quá bán rất nhỏ.`);
  } else if (ret5 != null && ret5 >= 0.02) {
    notes.push(`Vàng tăng ${(ret5 * 100).toFixed(1)}% trong 5 phiên — mô hình đang theo đà, và trừ nhẹ vì quá đà.`);
  }
  if (dy != null && dy >= 0.1) {
    notes.push(`Lợi suất 10 năm tăng ${dy.toFixed(2)} điểm phần trăm trong 20 phiên. Đây thường là lực đè mạnh hơn một tiêu đề địa chính trị đơn lẻ.`);
  } else if (dy != null && dy <= -0.1) {
    notes.push(`Lợi suất 10 năm giảm ${Math.abs(dy).toFixed(2)} điểm phần trăm trong 20 phiên — chi phí cơ hội của việc giữ vàng đang hạ.`);
  }
  if (input.newsCount < 3) {
    notes.push("Ít tin liên quan. Đừng đọc điểm tổng như thể mô hình đã 'biết' chính trị tuần này.");
  }
  notes.push("Điểm ngân hàng trung ương là nền nhiều năm, không phải ai đó vừa mua một lượng lớn.");

  return {
    price,
    composite,
    dailyVol: vol,
    factors,
    quantNote: notes.join(" "),
  };
}

export function biasLabel(composite: number) {
  if (composite > 0.35) return "Lệch tăng";
  if (composite > 0.12) return "Nghiêng tăng nhẹ";
  if (composite < -0.35) return "Lệch giảm";
  if (composite < -0.12) return "Nghiêng giảm nhẹ";
  return "Trung tính";
}

export function buildScenarios(
  composite: number,
  price: number,
  vol: number,
  horizon: Horizon,
  leadBull: string,
  leadBear: string,
): { scenarios: Scenario[]; low: number; high: number } {
  const days = HORIZON_DAYS[horizon];
  const k = horizon === "1d" ? 0.85 : horizon === "5d" ? 1.15 : 0.75;
  const up = 1 / (1 + Math.exp(-2.1 * composite * k));
  const down = 1 / (1 + Math.exp(2.1 * composite * k));
  const flat = Math.max(0.14, 0.38 * (1 - Math.min(1, Math.abs(composite))));
  const sum = up + down + flat;
  const raw = [up / sum, flat / sum, down / sum];
  const floors = raw.map((n) => Math.floor(n * 100));
  let left = 100 - floors.reduce((a, b) => a + b, 0);
  const order = raw
    .map((n, i) => ({ i, frac: n * 100 - floors[i]! }))
    .sort((a, b) => b.frac - a.frac);
  for (let i = 0; i < left; i++) floors[order[i % order.length]!.i]! += 1;

  const sigma = price * vol * Math.sqrt(days);
  const drift = composite * 0.5 * sigma;
  const low = price + drift - sigma;
  const high = price + drift + sigma;

  const scenarios: Scenario[] = [
    {
      name: "Tăng",
      probability: floors[0] ?? 0,
      tone: "up",
      detail: `Cần ${leadBull} giữ hướng hỗ trợ trong ${HORIZON_LABEL[horizon]}.`,
    },
    {
      name: "Đi ngang",
      probability: floors[1] ?? 0,
      tone: "flat",
      detail: "Các lực triệt tiêu. Giá dao động trong dải mà không phá cấu trúc.",
    },
    {
      name: "Giảm",
      probability: floors[2] ?? 0,
      tone: "down",
      detail: `Nghiêng theo ${leadBear}. Nếu nhân tố này đảo, nhánh này mất lực.`,
    },
  ];

  return { scenarios, low, high };
}

export function effectLine(score: number) {
  if (score > 0.12) return "đang nâng vàng";
  if (score < -0.12) return "đang đè vàng";
  return "ảnh hưởng đang nhỏ";
}
