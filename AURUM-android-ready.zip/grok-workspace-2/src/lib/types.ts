export type Horizon = "1d" | "5d" | "3m";
export type Focus = "all" | "politics" | "macro" | "flow" | "quant";
export type Lean = "bullish" | "bearish" | "mixed" | "quiet";
export type FactorGroup = "politics" | "macro" | "flow" | "quant";
export type Evidence = "measured" | "inferred" | "structural";

export type NewsItem = {
  id: string;
  title: string;
  link: string;
  source: string;
  publishedAt: string;
  lang: "vi" | "en";
  lean: Lean;
  score: number;
  tags: string[];
  note: string;
};

export type FlowSignal = {
  actorId: string;
  actor: string;
  side: "thu" | "bán" | "không rõ";
  size: string;
  evidence: string;
  confidence: number;
  sourceTitle: string;
};

export type Factor = {
  id: string;
  group: FactorGroup;
  name: string;
  score: number;
  weight: number;
  reading: string;
  mechanism: string;
  evidence: Evidence;
};

export type Quote = {
  id: string;
  label: string;
  price: number;
  changePct: number;
  unit: string;
  goldEffect: string;
};

export type Scenario = {
  name: string;
  probability: number;
  tone: "up" | "flat" | "down";
  detail: string;
};

export type DivKind = "bullish" | "bearish" | "none";

export type ProfileLevel = {
  poc: number;
  vah: number;
  val: number;
};

export type FrameRead = {
  tf: "M5" | "H1";
  bars: number;
  last: number;
  vwap: number | null;
  vwapLabel: string;
  vwapDistPct: number | null;
  vsDay: string;
  vsWeek: string;
  cvdDiv: DivKind;
  cvdFresh: boolean;
  cvdNote: string;
  obvDiv: DivKind;
  obvFresh: boolean;
  obvNote: string;
  volumeNote: string;
};

export type RiskAlert = {
  level: "cao" | "vừa";
  title: string;
  detail: string;
};

export type VtunCall = {
  bias: "bullish" | "bearish" | "neutral";
  headline: string;
  reasons: string[];
  invalidation: string;
};

export type TechBoard = {
  asOf: string;
  dayTag: string;
  weekTag: string;
  vpDay: ProfileLevel | null;
  vpWeek: ProfileLevel | null;
  m5: FrameRead | null;
  h1: FrameRead | null;
  risks: RiskAlert[];
  topRisk: "cao" | "vừa" | "thấp";
  vtun: VtunCall;
};

export type SourceCall = {
  id: string;
  claim: string;
  source: string;
  publishedAt: string;
  link: string;
};

export type AiCitation = {
  source: string;
  claim: string;
};

export type AiRead = {
  now: string;
  past: string;
  cited: AiCitation[];
  prediction: string;
  bias: "bullish" | "bearish" | "neutral";
  risks: string[];
};

export type DeskOk = {
  ok: true;
  asOf: string;
  quotes: Quote[];
  goldSeries: { label: string; close: number }[];
  factors: Factor[];
  composite: number;
  dailyVol: number;
  price: number;
  quantNote: string;
  news: NewsItem[];
  flows: FlowSignal[];
  caveats: string[];
  tech: TechBoard;
};

export type DeskResult = DeskOk | { ok: false; error: string };

export type ExpertImpact = {
  driver: string;
  direction: "bullish" | "bearish" | "mixed";
  magnitude: "nhỏ" | "vừa" | "lớn";
  explanation: string;
};

export type ExpertFlow = {
  actor: string;
  side: "thu" | "bán" | "không rõ";
  size: string;
  evidence: string;
  confidence: number;
};

export type ExpertScenario = {
  name: string;
  probability: number;
  path: string;
  level: string;
};

export type ExpertBrief = {
  bias: "bullish" | "bearish" | "neutral";
  confidence: number;
  headline: string;
  scenarios: ExpertScenario[];
  impacts: ExpertImpact[];
  flows: ExpertFlow[];
  narrative: string;
  political: string;
  watch: string[];
  invalidation: string;
};

export type FlowNote = {
  id: string;
  actor: string;
  side: "thu" | "bán";
  size: string;
  source: string;
  at: string;
};

export type SavedBrief = {
  at: string;
  question: string;
  horizon: Horizon;
  focus: Focus;
  brief: ExpertBrief;
};
