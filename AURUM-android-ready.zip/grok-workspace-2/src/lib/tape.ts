import { formatPx } from "@/lib/format";
import type { DivKind, FrameRead, ProfileLevel, RiskAlert, TechBoard, VtunCall } from "@/lib/types";

export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number };

const TZ = "Asia/Ho_Chi_Minh";
const BINS = 32;

const WD: Record<string, number> = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };

function dayKey(ms: number) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(ms);
}

function dayLabel(key: string) {
  const [, month, day] = key.split("-");
  return `${day}/${month} GMT+7`;
}

function weekStartKey(ms: number) {
  const key = dayKey(ms);
  const [year, month, day] = key.split("-").map(Number);
  const utc = Date.UTC(year ?? 1970, (month ?? 1) - 1, day ?? 1);
  const name = new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "UTC" }).format(new Date(utc));
  const monday = new Date(utc - (WD[name] ?? 0) * 86_400_000);
  const mm = String(monday.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(monday.getUTCDate()).padStart(2, "0");
  return `${monday.getUTCFullYear()}-${mm}-${dd}`;
}

function weekLabel(key: string) {
  const [, month, day] = key.split("-");
  return `từ ${day}/${month} GMT+7`;
}

function clean(candles: Candle[]) {
  return candles.filter(
    (c) =>
      Number.isFinite(c.t) &&
      Number.isFinite(c.o) &&
      Number.isFinite(c.h) &&
      Number.isFinite(c.l) &&
      Number.isFinite(c.c) &&
      c.c > 0 &&
      c.h >= c.l &&
      c.h > 0,
  );
}

function groupByDay(candles: Candle[]) {
  const groups = new Map<string, Candle[]>();
  for (const candle of candles) {
    const key = dayKey(candle.t * 1000);
    const list = groups.get(key);
    if (list) list.push(candle);
    else groups.set(key, [candle]);
  }
  return groups;
}

function latestDay(candles: Candle[], minBars: number) {
  const groups = groupByDay(candles);
  const keys = [...groups.keys()].sort();
  for (let i = keys.length - 1; i >= 0; i--) {
    const key = keys[i]!;
    const bars = groups.get(key) ?? [];
    if (bars.length >= minBars) return { key, bars };
  }
  const key = keys[keys.length - 1];
  if (!key) return null;
  return { key, bars: groups.get(key) ?? [] };
}

function weekSlice(candles: Candle[], minBars: number) {
  if (!candles.length) return null;
  const last = candles[candles.length - 1]!;
  const key = weekStartKey(last.t * 1000);
  const bars = candles.filter((c) => weekStartKey(c.t * 1000) === key);
  if (bars.length >= minBars) return { key, bars };
  const days = [...groupByDay(candles).keys()].sort().slice(-5);
  const fallback = candles.filter((c) => days.includes(dayKey(c.t * 1000)));
  if (fallback.length < 8) return bars.length ? { key, bars } : null;
  return { key: days[0] ?? key, bars: fallback };
}

function profile(candles: Candle[]): ProfileLevel | null {
  if (candles.length < 8) return null;
  let lo = Infinity;
  let hi = -Infinity;
  for (const c of candles) {
    lo = Math.min(lo, c.l);
    hi = Math.max(hi, c.h);
  }
  if (!(hi > lo)) return null;
  const bins = new Array<number>(BINS).fill(0);
  const span = hi - lo;
  let total = 0;
  for (const c of candles) {
    const vol = c.v > 0 ? c.v : Math.max(c.h - c.l, 0.01);
    let a = Math.floor(((c.l - lo) / span) * (BINS - 1));
    let b = Math.floor(((c.h - lo) / span) * (BINS - 1));
    a = Math.max(0, Math.min(BINS - 1, a));
    b = Math.max(a, Math.min(BINS - 1, b));
    const share = vol / (b - a + 1);
    for (let i = a; i <= b; i++) bins[i] = (bins[i] ?? 0) + share;
    total += vol;
  }
  let poc = 0;
  for (let i = 1; i < BINS; i++) if ((bins[i] ?? 0) > (bins[poc] ?? 0)) poc = i;
  let left = poc;
  let right = poc;
  let acc = bins[poc] ?? 0;
  const target = total * 0.7;
  while (acc < target && (left > 0 || right < BINS - 1)) {
    const nextLeft = left > 0 ? (bins[left - 1] ?? 0) : -1;
    const nextRight = right < BINS - 1 ? (bins[right + 1] ?? 0) : -1;
    if (nextRight >= nextLeft) {
      right += 1;
      acc += bins[right] ?? 0;
    } else {
      left -= 1;
      acc += bins[left] ?? 0;
    }
  }
  const mid = (i: number) => lo + ((i + 0.5) / BINS) * span;
  return {
    poc: Number(mid(poc).toFixed(2)),
    vah: Number(mid(right).toFixed(2)),
    val: Number(mid(left).toFixed(2)),
  };
}

function vwapOf(candles: Candle[]) {
  let pv = 0;
  let volume = 0;
  let priced = 0;
  for (const c of candles) {
    const vol = c.v > 0 ? c.v : 1;
    pv += ((c.h + c.l + c.c) / 3) * vol;
    volume += vol;
    if (c.v > 0) priced += 1;
  }
  if (!volume) return { vwap: null as number | null, thin: true };
  return { vwap: pv / volume, thin: priced < candles.length * 0.3 };
}

type DivRead = { kind: DivKind; fresh: boolean; note: string };

function swings(values: number[], k: number, kind: "high" | "low") {
  const found: { i: number; v: number }[] = [];
  for (let i = k; i < values.length - k; i++) {
    const pivot = values[i];
    if (pivot == null) continue;
    let ok = true;
    for (let j = i - k; j <= i + k; j++) {
      if (j === i) continue;
      const other = values[j];
      if (other == null) continue;
      if (kind === "high" && other >= pivot) ok = false;
      if (kind === "low" && other <= pivot) ok = false;
      if (!ok) break;
    }
    if (ok) found.push({ i, v: pivot });
  }
  return found;
}

function divergence(
  highs: number[],
  lows: number[],
  indicator: number[],
  k: number,
  freshBars: number,
  name: "CVD" | "OBV",
): DivRead {
  if (highs.length < k * 2 + 5) {
    return { kind: "none", fresh: false, note: `${name}: chưa đủ nến để chấm phân kỳ.` };
  }
  const hi = swings(highs, k, "high");
  const lo = swings(lows, k, "low");
  const cutoff = highs.length - freshBars;
  let bearish: { at: number } | null = null;
  let bullish: { at: number } | null = null;
  if (hi.length >= 2) {
    const a = hi[hi.length - 2]!;
    const b = hi[hi.length - 1]!;
    const ia = indicator[a.i];
    const ib = indicator[b.i];
    if (ia != null && ib != null && b.v > a.v * 1.0003 && ib < ia) bearish = { at: b.i };
  }
  if (lo.length >= 2) {
    const a = lo[lo.length - 2]!;
    const b = lo[lo.length - 1]!;
    const ia = indicator[a.i];
    const ib = indicator[b.i];
    if (ia != null && ib != null && b.v < a.v * 0.9997 && ib > ia) bullish = { at: b.i };
  }
  let kind: DivKind = "none";
  let at = -1;
  if (bearish && bullish) {
    if (bearish.at >= bullish.at) {
      kind = "bearish";
      at = bearish.at;
    } else {
      kind = "bullish";
      at = bullish.at;
    }
  } else if (bearish) {
    kind = "bearish";
    at = bearish.at;
  } else if (bullish) {
    kind = "bullish";
    at = bullish.at;
  }
  if (kind === "none") {
    return { kind: "none", fresh: false, note: `${name}: chưa thấy phân kỳ trên các đỉnh/đáy gần.` };
  }
  const fresh = at >= cutoff;
  const word = kind === "bearish" ? "giảm — giá đỉnh cao hơn nhưng chỉ báo thấp hơn" : "tăng — giá đáy thấp hơn nhưng chỉ báo cao hơn";
  const extra = bearish && bullish ? " Cả hai phía đều lệch, lấy nhịp gần hơn." : "";
  return {
    kind,
    fresh,
    note: `${name}: phân kỳ ${word}, ${fresh ? "còn sát giá" : "đã nguội"}.${extra}`,
  };
}

function flows(candles: Candle[]) {
  const highs: number[] = [];
  const lows: number[] = [];
  const cvd: number[] = [];
  const obv: number[] = [];
  let cvdSum = 0;
  let obvSum = 0;
  let prevClose: number | null = null;
  for (const c of candles) {
    const range = Math.max(c.h - c.l, Math.abs(c.c) * 1e-6);
    const vol = c.v > 0 ? c.v : 1;
    cvdSum += vol * ((c.c - c.o) / range);
    if (prevClose != null) {
      if (c.c > prevClose) obvSum += vol;
      else if (c.c < prevClose) obvSum -= vol;
    }
    prevClose = c.c;
    highs.push(c.h);
    lows.push(c.l);
    cvd.push(cvdSum);
    obv.push(obvSum);
  }
  return { highs, lows, cvd, obv };
}

function place(price: number, level: ProfileLevel | null, name: string) {
  if (!level) return `${name}: chưa đủ nến.`;
  const nums = `POC ${formatPx(level.poc)} · VAH ${formatPx(level.vah)} · VAL ${formatPx(level.val)}.`;
  const width = level.poc > 0 ? (level.vah - level.val) / level.poc : 0;
  if (width < 0.003) return `${name}: vùng giá trị hẹp, giá sát POC. ${nums}`;
  let where = "trong vùng giá trị, dưới POC";
  if (price > level.vah) where = "trên VAH";
  else if (price < level.val) where = "dưới VAL";
  else if (price >= level.poc) where = "trong vùng giá trị, trên POC";
  return `${name}: giá ${where}. ${nums}`;
}

function readFrame(
  tf: "M5" | "H1",
  candles: Candle[],
  vwapLabel: string,
  day: ProfileLevel | null,
  week: ProfileLevel | null,
  k: number,
  freshBars: number,
): FrameRead | null {
  if (candles.length < 8) return null;
  const last = candles[candles.length - 1]!.c;
  const { vwap, thin } = vwapOf(candles);
  const dist = vwap ? ((last - vwap) / vwap) * 100 : null;
  const { highs, lows, cvd, obv } = flows(candles);
  const cvdDiv = divergence(highs, lows, cvd, k, freshBars, "CVD");
  const obvDiv = divergence(highs, lows, obv, k, freshBars, "OBV");
  return {
    tf,
    bars: candles.length,
    last,
    vwap,
    vwapLabel,
    vwapDistPct: dist,
    vsDay: place(last, day, "VP DAY"),
    vsWeek: place(last, week, "VP WEEK"),
    cvdDiv: cvdDiv.kind,
    cvdFresh: cvdDiv.fresh,
    cvdNote: cvdDiv.note,
    obvDiv: obvDiv.kind,
    obvFresh: obvDiv.fresh,
    obvNote: obvDiv.note,
    volumeNote: thin ? "Khối lượng mỏng hoặc thiếu — VWAP gần với trung bình nến, CVD/OBV chỉ theo hướng nến." : "",
  };
}

function liveDiv(frame: FrameRead | null, which: "cvd" | "obv"): DivKind {
  if (!frame) return "none";
  if (which === "cvd") return frame.cvdFresh ? frame.cvdDiv : "none";
  return frame.obvFresh ? frame.obvDiv : "none";
}

function scoreFrame(frame: FrameRead | null, side: "day" | "week") {
  if (!frame) return 0;
  let score = 0;
  if (frame.vwapDistPct != null) {
    if (frame.vwapDistPct > 0.4) score += 2;
    else if (frame.vwapDistPct > 0.05) score += 1;
    else if (frame.vwapDistPct < -0.4) score -= 2;
    else if (frame.vwapDistPct < -0.05) score -= 1;
  }
  const text = side === "day" ? frame.vsDay : frame.vsWeek;
  if (text.includes("trên VAH")) score += 1;
  if (text.includes("trên POC")) score += 1;
  if (text.includes("dưới VAL")) score -= 1;
  if (text.includes("dưới POC")) score -= 1;
  const cvd = liveDiv(frame, "cvd");
  const obv = liveDiv(frame, "obv");
  if (cvd === "bullish") score += 2;
  if (cvd === "bearish") score -= 2;
  if (obv === "bullish") score += 1;
  if (obv === "bearish") score -= 1;
  return score;
}

function signed(n: number | null) {
  if (n == null || !Number.isFinite(n)) return "—";
  return `${n > 0 ? "+" : ""}${n.toFixed(2)}%`;
}

function buildCall(m5: FrameRead | null, h1: FrameRead | null, m5Score: number, h1Score: number): VtunCall {
  const bearDiv = liveDiv(h1, "cvd") === "bearish" || liveDiv(h1, "obv") === "bearish";
  const bullDiv = liveDiv(h1, "cvd") === "bullish" || liveDiv(h1, "obv") === "bullish";
  const aboveWeek = Boolean(h1?.vsWeek.includes("trên VAH") || m5?.vsWeek.includes("trên VAH"));
  const belowWeek = Boolean(h1?.vsWeek.includes("dưới VAL") || m5?.vsWeek.includes("dưới VAL"));
  const score = h1Score * 1.4 + m5Score;
  let bias: VtunCall["bias"] = "neutral";
  if (score >= 3) bias = "bullish";
  else if (score <= -3) bias = "bearish";

  let headline = "Trung tính. M5 và H1 chưa đồng thuận trên VP WEEK, VP DAY, VWAP và CVD/OBV.";
  let invalidation = "Hết trung tính khi M5 và H1 cùng một phía POC của VP WEEK và cùng một phía VWAP.";
  const h1Dist = h1?.vwapDistPct ?? 0;
  const m5Dist = m5?.vwapDistPct ?? 0;
  if (aboveWeek && bearDiv) {
    bias = "bearish";
    headline = "Không đuổi mua. Giá trên VAH của VP WEEK và H1 có phân kỳ giảm CVD/OBV.";
    invalidation = "Call này hỏng nếu H1 lấy lại trên VAH tuần mà CVD tạo đỉnh cao hơn cùng giá.";
  } else if (belowWeek && bullDiv) {
    bias = "bullish";
    headline = "Không đuổi bán. Giá dưới VAL của VP WEEK và H1 có phân kỳ tăng CVD/OBV.";
    invalidation = "Call này hỏng nếu H1 đóng tiếp dưới VAL tuần và phân kỳ tăng bị xóa.";
  } else if (bias === "bullish") {
    headline = "Nghiêng tăng. Giá giữ trên VWAP và POC, chưa có phân kỳ ngược còn hiệu lực.";
    invalidation = "Hỏng nếu H1 đóng dưới VAL của VP DAY và dưới VWAP ngày.";
  } else if (bias === "bearish") {
    headline = "Nghiêng giảm. Giá dưới VWAP hoặc POC, CVD/OBV không ủng hộ nhịp hồi.";
    invalidation = "Hỏng nếu H1 lấy lại POC của VP WEEK và CVD hết phân kỳ giảm.";
  } else if (h1Dist <= -0.8 && m5Dist >= 0) {
    headline = "Trung tính. M5 bám VWAP ngày, nhưng H1 còn dưới VWAP tuần — chưa đủ đồng thuận để nghiêng một phía.";
  } else if (h1Dist >= 0.8 && m5Dist <= 0) {
    headline = "Trung tính. H1 đang trên VWAP tuần, nhưng M5 chưa giữ được VWAP ngày.";
  }

  const reasons = [
    m5 ? `M5 — ${m5.vsWeek}` : "M5 — không có nến.",
    m5 ? `M5 — ${m5.vsDay}` : "",
    m5 ? `M5 — VWAP ${m5.vwapLabel}${m5.vwap != null ? ` ${formatPx(m5.vwap)}` : ""}, giá cách ${signed(m5.vwapDistPct)}.` : "",
    m5 ? `M5 — ${m5.cvdNote} ${m5.obvNote}` : "",
    h1 ? `H1 — ${h1.vsWeek}` : "H1 — không có nến.",
    h1 ? `H1 — ${h1.vsDay}` : "",
    h1 ? `H1 — VWAP ${h1.vwapLabel}${h1.vwap != null ? ` ${formatPx(h1.vwap)}` : ""}, giá cách ${signed(h1.vwapDistPct)}.` : "",
    h1 ? `H1 — ${h1.cvdNote} ${h1.obvNote}` : "",
    m5?.volumeNote ? `M5 — ${m5.volumeNote}` : "",
    h1?.volumeNote ? `H1 — ${h1.volumeNote}` : "",
  ].filter(Boolean);

  return { bias, headline, reasons, invalidation };
}

function pushRisk(risks: RiskAlert[], alert: RiskAlert) {
  if (risks.length >= 3) return;
  if (risks.some((item) => item.detail === alert.detail)) return;
  risks.push(alert);
}

export function buildTech(m5Raw: Candle[], h1Raw: Candle[]): TechBoard {
  const m5All = clean(m5Raw);
  const h1All = clean(h1Raw);
  const daySource = m5All.length >= 8 ? m5All : h1All;
  const day = latestDay(daySource, 8);
  const weekSource = h1All.length >= 8 ? h1All : m5All;
  const week = weekSlice(weekSource, 8);
  const vpDay = day ? profile(day.bars) : null;
  const vpWeek = week ? profile(week.bars) : null;
  const m5Day = latestDay(m5All, 8);
  const h1Week = weekSlice(h1All, 8);
  const m5 = m5Day ? readFrame("M5", m5Day.bars, "ngày GMT+7", vpDay, vpWeek, 4, 24) : null;
  const h1 = h1Week ? readFrame("H1", h1Week.bars, "tuần GMT+7", vpDay, vpWeek, 3, 8) : null;
  const m5Score = scoreFrame(m5, "day");
  const h1Score = scoreFrame(h1, "week");
  const risks: RiskAlert[] = [];
  const bearDiv = liveDiv(h1, "cvd") === "bearish" || liveDiv(h1, "obv") === "bearish";
  const bullDiv = liveDiv(h1, "cvd") === "bullish" || liveDiv(h1, "obv") === "bullish";
  const aboveWeek = Boolean(h1?.vsWeek.includes("trên VAH") || m5?.vsWeek.includes("trên VAH"));
  const belowWeek = Boolean(h1?.vsWeek.includes("dưới VAL") || m5?.vsWeek.includes("dưới VAL"));

  if (aboveWeek && bearDiv) {
    pushRisk(risks, {
      level: "cao",
      title: "Rủi ro cao",
      detail:
        "Giá nằm trên VAH của VP WEEK trong khi H1 có phân kỳ giảm CVD hoặc OBV. Đuổi mua ở đây dễ bị kéo về POC tuần.",
    });
  }
  if (belowWeek && bullDiv) {
    pushRisk(risks, {
      level: "cao",
      title: "Rủi ro cao",
      detail:
        "Giá nằm dưới VAL của VP WEEK trong khi H1 có phân kỳ tăng. Bán đuổi dễ gặp hồi về POC tuần.",
    });
  }
  if (m5 && liveDiv(m5, "cvd") !== "none" && liveDiv(m5, "cvd") === liveDiv(m5, "obv")) {
    const outside = m5.vsDay.includes("trên VAH") || m5.vsDay.includes("dưới VAL");
    if (outside) {
      pushRisk(risks, {
        level: "cao",
        title: "Rủi ro cao",
        detail: "M5 đang ở ngoài vùng giá trị ngày và CVD cùng OBV phân kỳ ngược chiều giá.",
      });
    }
  }
  if (aboveWeek && !bearDiv) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "Giá đang trên VAH của VP WEEK. Chưa có phân kỳ giảm, nhưng đuổi mua ngoài vùng giá trị tuần dễ bị kéo về POC.",
    });
  }
  if (belowWeek && !bullDiv) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "Giá đang dưới VAL của VP WEEK. Chưa có phân kỳ tăng, nhưng đuổi bán ngoài vùng giá trị tuần dễ gặp hồi về POC.",
    });
  }
  if (
    h1?.vwapDistPct != null &&
    h1.vwapDistPct > 0.15 &&
    (liveDiv(h1, "cvd") === "bearish" || liveDiv(h1, "obv") === "bearish") &&
    !aboveWeek
  ) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "H1 nằm trên VWAP tuần nhưng CVD hoặc OBV phân kỳ giảm. Tiềm ẩn hồi về VWAP.",
    });
  }
  if (
    h1?.vwapDistPct != null &&
    h1.vwapDistPct < -0.15 &&
    (liveDiv(h1, "cvd") === "bullish" || liveDiv(h1, "obv") === "bullish") &&
    !belowWeek
  ) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "H1 nằm dưới VWAP tuần nhưng CVD hoặc OBV phân kỳ tăng. Tiềm ẩn hồi về VWAP.",
    });
  }
    if ((m5Score >= 2 && h1Score <= -2) || (m5Score <= -2 && h1Score >= 2)) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "M5 và H1 lệch nhau trên VWAP và VP. Khung nhỏ có thể chỉ là nhiễu của khung giờ.",
    });
  }
  if (h1?.vwapDistPct != null && Math.abs(h1.vwapDistPct) >= 1.5) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: `H1 cách VWAP tuần ${signed(h1.vwapDistPct)}. Giá lệch giá trị tuần — tiềm ẩn bị kéo về VWAP nếu khung nhỏ không giữ được.`,
    });
  }
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: `Giá cách VWAP ngày ${signed(m5.vwapDistPct)}. Phiên đang căng so với giá trị giao dịch — vào cùng chiều lúc này là đuổi.`,
    });
  }
  if (!m5 && !h1) {
    pushRisk(risks, {
      level: "vừa",
      title: "Rủi ro vừa",
      detail: "Chưa đọc được nến M5/H1 nên chưa chấm được VP, VWAP và phân kỳ. Đừng coi phần tin là tín hiệu vào lệnh.",
    });
  }

  const lastTs = m5All[m5All.length - 1]?.t ?? h1All[h1All.length - 1]?.t ?? Math.floor(Date.now() / 1000);
  const topRisk: TechBoard["topRisk"] = risks.some((r) => r.level === "cao") ? "cao" : risks.length ? "vừa" : "thấp";
  return {
    asOf: new Date(lastTs * 1000).toISOString(),
    dayTag: day ? dayLabel(day.key) : "chưa có phiên",
    weekTag: week ? weekLabel(week.key) : "chưa có tuần",
    vpDay,
    vpWeek,
    m5,
    h1,
    risks,
    topRisk,
    vtun: buildCall(m5, h1, m5Score, h1Score),
  };
}
