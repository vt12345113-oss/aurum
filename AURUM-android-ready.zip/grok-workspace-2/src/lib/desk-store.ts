import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { FlowNote, SavedBrief } from "@/lib/types";

type DeskState = {
  notes: FlowNote[];
  brief: SavedBrief | null;
  addNote: (note: Omit<FlowNote, "id" | "at">) => void;
  removeNote: (id: string) => void;
  setBrief: (brief: SavedBrief) => void;
};

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      notes: [],
      brief: null,
      addNote: (note) =>
        set((state) => ({
          notes: [
            {
              ...note,
              id: `${Date.now().toString(36)}-${state.notes.length}`,
              at: new Date().toISOString(),
            },
            ...state.notes,
          ].slice(0, 30),
        })),
      removeNote: (id) => set((state) => ({ notes: state.notes.filter((n) => n.id !== id) })),
      setBrief: (brief) => set({ brief }),
    }),
    {
      name: "aurum-desk",
      skipHydration: true,
      partialize: (state) => ({ notes: state.notes, brief: state.brief }),
    },
  ),
);
