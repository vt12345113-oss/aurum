import { useEffect, useMemo, useState, type FormEvent } from "react";
import { RefreshCw } from "lucide-react";
import { runExpert } from "@/lib/analyze.functions";
import { ACTORS } from "@/lib/classify";
import { useDesk } from "@/lib/desk-store";
import { formatPx, formatSignedPct, formatWhen } from "@/lib/format";
import { getDesk } from "@/lib/market.functions";
import { biasLabel, buildScenarios, HORIZON_LABEL } from "@/lib/quant";
import type { DeskResult, Factor, FactorGroup, Focus, Horizon, SavedBrief } from "@/lib/types";
import { PriceChart } from "@/components/price-chart";
import { NewsRead, RiskStrip, VtunLine } from "@/components/news-read";
import { Button } from "@/components/ui/button";

const GROUPS: { id: FactorGroup; label: string }[] = [
  { id: "politics", label: "Chính trị thế giới" },
  { id: "macro", label: "Vĩ mô" },
  { id: "flow", label: "Dòng tiền" },
  { id: "quant", label: "Quant" },
];

const TABS = [
  { id: "model", label: "Mô hình" },
  { id: "factors", label: "Nhân tố" },
  { id: "flows", label: "Dòng tiền" },
  { id: "news", label: "Tin" },
] as const;

type Tab = (typeof TABS)[number]["id"];

const PROMPTS = [
  "Ai đang thu hoặc bán vàng lượng lớn, và tin nào thực sự chứng minh?",
  "Lợi suất 10 năm cao thì chính trị còn nâng được vàng không?",
  "Xác suất vàng đi tiếp theo hướng 5 phiên vừa rồi?",
];

const FOCUS_LABEL: Record<Focus, string> = {
  all: "Tất cả lớp thông tin",
  politics: "Chính trị thế giới",
  macro: "Vĩ mô — lợi suất, Fed, USD",
  flow: "Dòng tiền lớn",
  quant: "Quant — đà và xác suất",
};

function scoreClass(n: number) {
  if (n > 0.12) return "text-gold";
  if (n < -0.12) return "text-down";
  return "text-muted";
}

function changeClass(id: string, n: number) {
  if (Math.abs(n) < 0.005) return "text-muted";
  if (n < 0) return "text-down";
  return id === "gold" ? "text-gold" : "text-fg";
}

function evidenceLabel(kind: Factor["evidence"]) {
  if (kind === "measured") return "Đo được";
  if (kind === "inferred") return "Suy từ tin";
  return "Nền nhiều năm";
}

function directionLabel(direction: "bullish" | "bearish" | "mixed") {
  if (direction === "bullish") return "nâng vàng";
  if (direction === "bearish") return "đè vàng";
  return "hai chiều";
}

export function DeskApp({ initial }: { initial: DeskResult }) {
  const [data, setData] = useState(initial);
  const [tab, setTab] = useState<Tab>("news");
  const [horizon, setHorizon] = useState<Horizon>("5d");
  const [focus, setFocus] = useState<Focus>("all");
  const [question, setQuestion] = useState("");
  const [extra, setExtra] = useState("");
  const [running, setRunning] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [live, setLive] = useState<SavedBrief | null>(null);
  const [ready, setReady] = useState(false);
  const [actor, setActor] = useState("");
  const [side, setSide] = useState<"thu" | "bán">("thu");
  const [size, setSize] = useState("");
  const [source, setSource] = useState("");

  const notes = useDesk((s) => s.notes);
  const saved = useDesk((s) => s.brief);
  const addNote = useDesk((s) => s.addNote);
  const removeNote = useDesk((s) => s.removeNote);

  useEffect(() => {
    setData(initial);
  }, [initial]);

  useEffect(() => {
    let on = true;
    const pending = useDesk.persist.rehydrate();
    if (pending && typeof pending.then === "function") {
      void pending.then(() => {
        if (on) setReady(true);
      });
    } else if (on) {
      setReady(true);
    }
    return () => {
      on = false;
    };
  }, []);

  const shown = live ?? (ready ? saved : null);
  const shownNotes = ready ? notes : [];

  const view = useMemo(() => {
    if (!data.ok) return null;
    const bear = [...data.factors].sort((a, b) => a.score - b.score)[0];
    const bull = [...data.factors].sort((a, b) => b.score - a.score)[0];
    const model = buildScenarios(
      data.composite,
      data.price,
      data.dailyVol,
      horizon,
      bull?.name ?? "nhân tố hỗ trợ",
      bear?.name ?? "nhân tố cản",
    );
    return { ...model, bull, bear };
  }, [data, horizon]);

  async function refresh() {
    setRefreshing(true);
    setError(null);
    try {
      const next = await getDesk({ data: { fresh: true } });
      setData(next);
      if (!next.ok) setError(next.error);
    } catch (err) {
      console.error("[aurum] refresh failed", err);
      setError("Không làm mới được dữ liệu. Kiểm tra kết nối rồi thử lại.");
    } finally {
      setRefreshing(false);
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!data.ok || !view || running) return;
    setRunning(true);
    setError(null);
    try {
      const result = await runExpert({
        data: {
          price: data.price,
          composite: data.composite,
          horizon,
          focus,
          question,
          extra,
          probabilities: view.scenarios.map((s) => ({ name: s.name, probability: s.probability })),
          band: `${formatPx(view.low)} – ${formatPx(view.high)}`,
          factors: data.factors.map((f) => ({
            name: f.name,
            score: f.score,
            reading: f.reading,
            evidence: f.evidence,
          })),
          news: data.news.slice(0, 8).map((n) => ({
            title: n.title,
            source: n.source,
            lean: n.lean,
            note: n.note,
          })),
          flows: data.flows.map((f) => ({
            actor: f.actor,
            side: f.side,
            size: f.size,
            evidence: f.evidence,
            confidence: f.confidence,
          })),
          quantNote: data.quantNote,
        },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      const next: SavedBrief = {
        at: new Date().toISOString(),
        question: question.trim(),
        horizon,
        focus,
        brief: result.brief,
      };
      setLive(next);
      useDesk.getState().setBrief(next);
    } catch (err) {
      console.error("[aurum] expert request failed", err);
      setError("Không gọi được chuyên gia. Kiểm tra kết nối rồi thử lại.");
    } finally {
      setRunning(false);
    }
  }

  function addFlow(event: FormEvent) {
    event.preventDefault();
    if (!actor.trim() || !source.trim()) return;
    addNote({ actor: actor.trim(), side, size: size.trim() || "không nêu quy mô", source: source.trim() });
    setActor("");
    setSize("");
    setSource("");
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="h-1 bg-gold" />
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 md:flex-row md:items-end md:justify-between">
          <div className="max-w-xl">
            <p className="font-mono text-xs tracking-widest text-gold">VTUN · XAUUSD · GMT+7</p>
            <h1 className="mt-2 font-serif text-4xl text-fg md:text-5xl">AURUM</h1>
            <p className="mt-2 text-sm text-muted">
              Bàn của VTUN. Đọc tin thì tách hiện và cũ, ghi nguồn nếu là người khác, và chỉ ký dự đoán VTUN khi có lý do. Kỹ thuật dùng VP WEEK, VP DAY, VWAP, CVD/OBV trên M5 và H1.
            </p>
          </div>
          <div className="flex items-end justify-between gap-4 md:block md:text-right">
            <div>
              <p className="font-mono text-xs text-muted">COMEX GC=F · sát XAUUSD</p>
              <p className="font-mono text-3xl tabular-nums text-gold md:text-4xl">
                {data.ok ? formatPx(data.price) : "—"}
              </p>
              {data.ok ? (
                <p className={`font-mono text-sm tabular-nums ${changeClass("gold", data.quotes[0]?.changePct ?? 0)}`}>
                  {formatSignedPct(data.quotes.find((q) => q.id === "gold")?.changePct ?? 0)} · {formatWhen(data.asOf)}
                </p>
              ) : (
                <p className="text-sm text-down">{data.error}</p>
              )}
            </div>
            <Button variant="line" className="md:mt-3" onClick={() => void refresh()} disabled={refreshing}>
              <RefreshCw className="size-4" aria-hidden="true" />
              {refreshing ? "Đang tải" : "Làm mới"}
            </Button>
          </div>
        </div>
      </header>

      {data.ok ? <RiskStrip tech={data.tech} /> : null}
      {data.ok ? <VtunLine tech={data.tech} /> : null}

      {data.ok ? (
        <div className="border-b border-line">
          <div className="mx-auto max-w-6xl overflow-x-auto px-4">
            <div className="flex w-max gap-6 py-3">
              {data.quotes
                .filter((q) => q.id !== "gold")
                .map((q) => (
                  <div key={q.id} className="min-w-36">
                    <p className="text-xs text-muted">{q.label}</p>
                    <p className="font-mono text-sm tabular-nums text-fg">
                      {q.id === "us10y" ? `${formatPx(q.price)}%` : formatPx(q.price)}
                      <span className={`ml-2 ${changeClass(q.id, q.changePct)}`}>{formatSignedPct(q.changePct)}</span>
                    </p>
                    <p className="text-xs text-muted">{q.goldEffect}</p>
                  </div>
                ))}
            </div>
          </div>
        </div>
      ) : null}

      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]">
        <section className="order-2 min-w-0 lg:sticky lg:top-4 lg:order-1 lg:self-start">
          <form onSubmit={(event) => void onSubmit(event)} className="rounded-xl border border-line bg-surface p-4 md:p-5">
            <h2 className="font-serif text-2xl">Form chuyên gia</h2>
            <p className="mt-1 text-sm text-muted">
              Mô hình chấm ngay. Bấm nút để chuyên gia viết ảnh hưởng, chính trị và dòng tiền — có thể để trống câu hỏi.
            </p>
            <div className="mt-4 grid gap-4">
              <label className="block text-sm">
                <span className="mb-1 block text-xs text-muted">Khung thời gian</span>
                <select
                  id="horizon"
                  value={horizon}
                  onChange={(event) => setHorizon(event.target.value as Horizon)}
                  className="h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm text-fg"
                >
                  {(Object.keys(HORIZON_LABEL) as Horizon[]).map((key) => (
                    <option key={key} value={key}>
                      {HORIZON_LABEL[key]}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-sm">
                <span className="mb-1 block text-xs text-muted">Trọng tâm</span>
                <select
                  id="focus"
                  value={focus}
                  onChange={(event) => setFocus(event.target.value as Focus)}
                  className="h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm text-fg"
                >
                  {(Object.keys(FOCUS_LABEL) as Focus[]).map((key) => (
                    <option key={key} value={key}>
                      {FOCUS_LABEL[key]}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block text-sm">
                <span className="mb-1 block text-xs text-muted">Câu hỏi</span>
                <textarea
                  id="question"
                  value={question}
                  onChange={(event) => setQuestion(event.target.value)}
                  rows={3}
                  placeholder="Ví dụ: nếu lợi suất giữ trên 5%, xác suất vàng yếu trong 5 phiên?"
                  className="w-full rounded-lg border border-line bg-bg px-3 py-3 text-sm text-fg placeholder:text-muted"
                />
              </label>
              <div className="flex flex-col gap-2">
                {PROMPTS.map((prompt) => (
                  <button
                    key={prompt}
                    type="button"
                    onClick={() => setQuestion(prompt)}
                    className="min-h-11 rounded-lg border border-line px-3 py-2 text-left text-xs text-muted hover:border-gold hover:text-fg"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
              <label className="block text-sm">
                <span className="mb-1 block text-xs text-muted">Dán thêm tin (không bắt buộc)</span>
                <textarea
                  id="extra"
                  value={extra}
                  onChange={(event) => setExtra(event.target.value)}
                  rows={3}
                  placeholder="Dán tiêu đề hoặc đoạn ngắn. Sẽ được đánh dấu là chưa kiểm chứng."
                  className="w-full rounded-lg border border-line bg-bg px-3 py-3 text-sm text-fg placeholder:text-muted"
                />
              </label>
              <Button type="submit" disabled={!data.ok || running}>
                {running ? "Đang chấm và viết…" : "Chấm xác suất và giải thích"}
              </Button>
              <p className="text-xs text-muted">Không phải khuyến nghị đầu tư. Mỗi lần bấm tốn một lượt viết.</p>
              {error ? <p className="text-sm text-down">{error}</p> : null}
            </div>
          </form>

          {data.ok && view ? (
            <div className="mt-4 rounded-xl border border-line bg-surface p-4 md:p-5">
              <p className="font-mono text-xs tracking-widest text-muted">MÔ HÌNH NHÂN TỐ · {HORIZON_LABEL[horizon]}</p>
              <p className="mt-2 font-serif text-2xl">{biasLabel(data.composite)}</p>
              <p className="font-mono text-sm tabular-nums text-muted">
                Điểm {(data.composite * 100).toFixed(0)} · −100 bán, +100 mua
              </p>
              <div className="mt-4 grid grid-cols-3 gap-2">
                {view.scenarios.map((scenario) => {
                  const top = Math.max(...view.scenarios.map((s) => s.probability));
                  return (
                    <div key={scenario.name} className="rounded-lg border border-line bg-bg p-2">
                      <p className="text-xs text-muted">{scenario.name}</p>
                      <p className={`font-mono text-xl tabular-nums ${scenario.probability === top ? "text-gold" : "text-fg"}`}>
                        {scenario.probability}%
                      </p>
                    </div>
                  );
                })}
              </div>
              <p className="mt-3 text-sm text-muted">
                Dải một độ lệch chuẩn: {formatPx(view.low)} – {formatPx(view.high)}. Độ phân tán lịch sử, không phải mục tiêu.
              </p>
              <p className="mt-2 text-sm text-muted">{data.quantNote}</p>
            </div>
          ) : null}

          {shown ? (
            <div className="lg:hidden">
              <BriefCard saved={shown} />
            </div>
          ) : null}
        </section>

        <section className="order-1 min-w-0 lg:order-2">
          <div role="tablist" aria-label="Lớp dữ liệu" className="flex gap-2 overflow-x-auto border-b border-line">
            {TABS.map((item) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={tab === item.id}
                onClick={() => setTab(item.id)}
                className={`h-11 shrink-0 border-b-2 px-3 text-sm ${tab === item.id ? "border-gold text-fg" : "border-transparent text-muted"}`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-4" role="tabpanel">
            {tab === "model" && data.ok && view ? (
              <div className="grid gap-4">
                <div className="rounded-xl border border-line bg-surface p-4">
                  <h2 className="font-serif text-xl">Sáu tháng giá vàng</h2>
                  <PriceChart series={data.goldSeries} />
                </div>
                <ul className="grid gap-3">
                  {view.scenarios.map((scenario) => (
                    <li key={scenario.name} className="rounded-xl border border-line bg-surface p-4">
                      <p className="text-sm text-muted">
                        {scenario.name} · {scenario.probability}%
                      </p>
                      <p className="mt-1 text-sm">{scenario.detail}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {tab === "factors" && data.ok ? (
              <div className="grid gap-6">
                {GROUPS.map((group) => (
                  <section key={group.id}>
                    <h2 className="font-serif text-xl">{group.label}</h2>
                    <div className="mt-2">
                      {data.factors
                        .filter((factor) => factor.group === group.id)
                        .map((factor) => (
                          <article key={factor.id} className="border-b border-line py-4">
                            <div className="flex items-baseline justify-between gap-3">
                              <h3 className="text-sm font-medium">{factor.name}</h3>
                              <span className={`font-mono text-sm tabular-nums ${scoreClass(factor.score)}`}>
                                {factor.score > 0 ? "+" : ""}
                                {Math.round(factor.score * 100)}
                              </span>
                            </div>
                            <p className="mt-1 text-xs text-muted">
                              {evidenceLabel(factor.evidence)} · trọng số {Math.round(factor.weight * 100)}%
                            </p>
                            <p className="mt-2 text-sm">{factor.reading}</p>
                            <Diverging score={factor.score} />
                            <p className="mt-2 text-sm text-muted">{factor.mechanism}</p>
                          </article>
                        ))}
                    </div>
                  </section>
                ))}
              </div>
            ) : null}

            {tab === "flows" && data.ok ? (
              <div className="grid gap-4">
                <p className="text-sm text-muted">
                  Ô chỉ có chữ “thu” hoặc “bán” khi tiêu đề 7 ngày nói vậy, hoặc khi bạn tự ghi nguồn. Trống nghĩa là chưa biết — không phải là không ai giao dịch.
                </p>
                <ul className="grid gap-3">
                  {ACTORS.map((actorDef) => {
                    const hits = data.flows.filter((flow) => flow.actorId === actorDef.id);
                    return (
                      <li key={actorDef.id} className="rounded-xl border border-line bg-surface p-4">
                        <div className="flex items-baseline justify-between gap-3">
                          <h3 className="text-sm font-medium">{actorDef.name}</h3>
                          <span className="text-xs text-muted">{hits.length ? `${hits.length} tín hiệu` : "chưa có tin"}</span>
                        </div>
                        <p className="mt-1 text-sm text-muted">{actorDef.role}</p>
                        {hits.map((hit) => (
                          <p key={`${hit.side}-${hit.sourceTitle}`} className="mt-2 text-sm">
                            <span className={hit.side === "thu" ? "text-gold" : hit.side === "bán" ? "text-down" : "text-muted"}>
                              {hit.side}
                            </span>
                            {" · "}
                            {hit.size}. Tin cậy tiêu đề {hit.confidence}/100. {hit.evidence}
                          </p>
                        ))}
                      </li>
                    );
                  })}
                  <li className="rounded-xl border border-line bg-surface p-4">
                    <h3 className="text-sm font-medium">Quỹ quốc gia</h3>
                    <p className="mt-1 text-sm text-muted">
                      Giao dịch thường không ra theo tuần. Chỉ điền khi bạn có nguồn riêng trong sổ tay.
                    </p>
                  </li>
                </ul>

                <form onSubmit={addFlow} className="rounded-xl border border-line bg-surface p-4">
                  <h2 className="font-serif text-xl">Sổ tay của bạn</h2>
                  <p className="mt-1 text-sm text-muted">Ghi một giao dịch lớn bạn đã đọc ở nơi khác. Lưu trên máy này.</p>
                  <div className="mt-4 grid gap-3">
                    <input
                      id="note-actor"
                      value={actor}
                      onChange={(event) => setActor(event.target.value)}
                      placeholder="Ai — ví dụ PBOC, GLD, một quỹ"
                      className="h-11 rounded-lg border border-line bg-bg px-3 text-sm"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <select
                        id="note-side"
                        value={side}
                        onChange={(event) => setSide(event.target.value as "thu" | "bán")}
                        className="h-11 rounded-lg border border-line bg-bg px-3 text-sm"
                      >
                        <option value="thu">Thu</option>
                        <option value="bán">Bán</option>
                      </select>
                      <input
                        id="note-size"
                        value={size}
                        onChange={(event) => setSize(event.target.value)}
                        placeholder="Quy mô"
                        className="h-11 rounded-lg border border-line bg-bg px-3 text-sm"
                      />
                    </div>
                    <input
                      id="note-source"
                      value={source}
                      onChange={(event) => setSource(event.target.value)}
                      placeholder="Nguồn — bài báo, thông cáo, ngày"
                      className="h-11 rounded-lg border border-line bg-bg px-3 text-sm"
                    />
                    <Button type="submit" variant="line" disabled={!actor.trim() || !source.trim()}>
                      Thêm vào sổ
                    </Button>
                  </div>
                  <ul className="mt-4 grid gap-3">
                    {shownNotes.map((note) => (
                      <li key={note.id} className="border-t border-line pt-3 text-sm">
                        <p>
                          <span className={note.side === "thu" ? "text-gold" : "text-down"}>{note.side}</span>
                          {" · "}
                          {note.actor} · {note.size}
                        </p>
                        <p className="text-muted">{note.source}</p>
                        <button type="button" onClick={() => removeNote(note.id)} className="mt-1 text-xs text-muted underline">
                          Xóa
                        </button>
                      </li>
                    ))}
                    {ready && shownNotes.length === 0 ? <li className="text-sm text-muted">Sổ còn trống.</li> : null}
                  </ul>
                </form>
              </div>
            ) : null}

            {tab === "news" && data.ok ? <NewsRead news={data.news} tech={data.tech} /> : null}

            {!data.ok ? <p className="text-sm text-down">{data.error}</p> : null}
          </div>

          {shown ? (
            <div className="hidden lg:block">
              <BriefCard saved={shown} />
            </div>
          ) : null}

          {data.ok ? (
            <details className="mt-6 rounded-xl border border-line bg-surface p-4">
              <summary className="cursor-pointer text-sm">Những gì bàn này không biết</summary>
              <ul className="mt-3 grid gap-2 text-sm text-muted">
                {data.caveats.map((caveat) => (
                  <li key={caveat}>{caveat}</li>
                ))}
              </ul>
            </details>
          ) : null}
        </section>
      </main>
    </div>
  );
}

function Diverging({ score }: { score: number }) {
  const pct = Math.round(score * 100);
  const width = Math.abs(pct) / 2;
  return (
    <div className="relative mt-3 h-1.5 rounded-full bg-raised">
      <div
        className={`absolute top-0 h-full rounded-full ${pct >= 0 ? "bg-gold" : "bg-down"}`}
        style={{ width: `${width}%`, left: pct >= 0 ? "50%" : `${50 - width}%` }}
      />
    </div>
  );
}

function BriefCard({ saved }: { saved: SavedBrief }) {
  const { brief } = saved;
  const bias =
    brief.bias === "bullish" ? "Nghiêng tăng" : brief.bias === "bearish" ? "Nghiêng giảm" : "Trung tính";
  return (
    <article className="mt-6 rounded-xl border border-gold bg-surface p-4 md:p-5">
      <p className="font-mono text-xs tracking-widest text-gold">
        BẢN AI · KHÔNG PHẢI VTUN · {HORIZON_LABEL[saved.horizon]} · {formatWhen(saved.at)}
      </p>
      <h2 className="mt-2 font-serif text-2xl">{brief.headline}</h2>
      <p className="mt-1 text-sm text-muted">
        {bias} · độ chắc của bài viết {brief.confidence}/100
        {saved.question ? ` · câu hỏi: ${saved.question}` : ""}
      </p>
      <p className="mt-2 text-xs text-muted">Dự đoán của VTUN nằm ở tab Tin, luôn có phần lý do. Bài này là AI.</p>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {brief.scenarios.map((scenario) => (
          <div key={scenario.name} className="rounded-lg border border-line bg-bg p-2">
            <p className="text-xs text-muted">{scenario.name}</p>
            <p className="font-mono text-xl tabular-nums text-gold">{scenario.probability}%</p>
            <p className="mt-1 text-xs text-muted">{scenario.level}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-3">
        {brief.scenarios.map((scenario) => (
          <p key={`${scenario.name}-path`} className="text-sm">
            <span className="text-muted">{scenario.name}. </span>
            {scenario.path}
          </p>
        ))}
      </div>
      <h3 className="mt-5 font-serif text-xl">Ảnh hưởng</h3>
      <ol className="mt-2 grid gap-3">
        {brief.impacts.map((impact, index) => (
          <li key={`${impact.driver}-${index}`} className="text-sm">
            <span className="font-medium">{impact.driver}</span>
            <span className="text-muted">
              {" "}
              · {directionLabel(impact.direction)} · lực {impact.magnitude}.{" "}
            </span>
            {impact.explanation}
          </li>
        ))}
      </ol>
      <h3 className="mt-5 font-serif text-xl">Chính trị thế giới</h3>
      <p className="mt-2 text-sm">{brief.political}</p>
      <h3 className="mt-5 font-serif text-xl">Ai thu, ai bán</h3>
      {brief.flows.length === 0 ? (
        <p className="mt-2 text-sm text-muted">Không đủ nguồn để chỉ tên một bên đang gom hoặc xả lượng lớn.</p>
      ) : (
        <ul className="mt-2 grid gap-2">
          {brief.flows.map((flow) => (
            <li key={`${flow.actor}-${flow.side}`} className="text-sm">
              <span className={flow.side === "thu" ? "text-gold" : flow.side === "bán" ? "text-down" : "text-muted"}>
                {flow.side}
              </span>
              {" · "}
              {flow.actor} · {flow.size}. Tin cậy {flow.confidence}/100. {flow.evidence}
            </li>
          ))}
        </ul>
      )}
      <h3 className="mt-5 font-serif text-xl">Luận điểm</h3>
      <p className="mt-2 text-sm">{brief.narrative}</p>
      {brief.watch.length ? (
        <>
          <h3 className="mt-5 font-serif text-xl">Theo dõi tiếp</h3>
          <ul className="mt-2 grid gap-1 text-sm text-muted">
            {brief.watch.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </>
      ) : null}
      <h3 className="mt-5 font-serif text-xl">Điều làm hỏng luận điểm</h3>
      <p className="mt-2 text-sm text-muted">{brief.invalidation}</p>
    </article>
  );
}
