import { useState } from "react";
import { readNews } from "@/lib/read.functions";
import { isForecast, relatedNews, sourceCalls, splitByAge } from "@/lib/claims";
import { formatPx, formatWhen } from "@/lib/format";
import type { AiRead, DivKind, FrameRead, NewsItem, TechBoard, VtunCall } from "@/lib/types";
import { Button } from "@/components/ui/button";

const FILTERS = [
  ["all", "Tất cả"],
  ["bull", "Hỗ trợ"],
  ["bear", "Áp lực"],
  ["politics", "Chính trị"],
  ["flow", "Dòng tiền"],
  ["call", "Có dự đoán"],
] as const;

type FilterId = (typeof FILTERS)[number][0];

function biasWord(bias: "bullish" | "bearish" | "neutral") {
  if (bias === "bullish") return "Nghiêng tăng";
  if (bias === "bearish") return "Nghiêng giảm";
  return "Trung tính";
}

function divWord(kind: DivKind, fresh: boolean) {
  if (kind === "none") return "không phân kỳ";
  const name = kind === "bearish" ? "phân kỳ giảm" : "phân kỳ tăng";
  return fresh ? name : `${name}, đã nguội`;
}

function divClass(kind: DivKind, fresh: boolean) {
  if (!fresh || kind === "none") return "text-muted";
  return kind === "bearish" ? "text-down" : "text-gold";
}

function leanWord(lean: NewsItem["lean"]) {
  if (lean === "bullish") return "Hỗ trợ vàng";
  if (lean === "bearish") return "Áp lực bán";
  if (lean === "mixed") return "Hai chiều";
  return "Chưa chấm";
}

function clash(item: NewsItem, bias: VtunCall["bias"]) {
  if (item.lean === "bullish" && bias === "bearish") {
    return "Tin đang đọc nghiêng hỗ trợ vàng, nhưng VTUN đang nghiêng giảm. Một tiêu đề không xóa cảnh báo kỹ thuật.";
  }
  if (item.lean === "bearish" && bias === "bullish") {
    return "Tin đang đọc nghiêng áp lực bán, nhưng VTUN đang nghiêng tăng. Một tiêu đề không xóa cảnh báo kỹ thuật.";
  }
  return null;
}

export function VtunLine({ tech }: { tech: TechBoard }) {
  return (
    <div className="border-b border-line">
      <p className="mx-auto max-w-6xl px-4 py-3 text-sm">
        <span className="text-gold">Dự đoán VTUN · {biasWord(tech.vtun.bias)}</span>
        {" · "}
        {tech.vtun.headline}
        <span className="text-muted"> · lý do ở tab Tin</span>
      </p>
    </div>
  );
}

export function RiskStrip({ tech }: { tech: TechBoard }) {
  if (tech.topRisk === "thấp") return null;
  const top = tech.risks[0];
  if (!top) return null;
  return (
    <div className={top.level === "cao" ? "border-b border-down" : "border-b border-gold"}>
      <p className="mx-auto max-w-6xl px-4 py-3 text-sm">
        <span className={top.level === "cao" ? "text-down" : "text-gold"}>{top.title}. </span>
        {top.detail}
      </p>
    </div>
  );
}

export function NewsRead({ news, tech }: { news: NewsItem[]; tech: TechBoard }) {
  const [filter, setFilter] = useState<FilterId>("all");
  const [picked, setPicked] = useState<string | null>(null);
  const [reads, setReads] = useState<Record<string, AiRead>>({});
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filtered = news.filter((item) => {
    if (filter === "bull") return item.lean === "bullish";
    if (filter === "bear") return item.lean === "bearish";
    if (filter === "politics") return item.tags.some((tag) => tag === "chiến sự" || tag === "chính trị" || tag === "hạ nhiệt");
    if (filter === "flow") return item.tags.includes("dòng tiền");
    if (filter === "call") return isForecast(item.title);
    return true;
  });
  const selected = filtered.find((item) => item.id === picked) ?? filtered[0] ?? null;
  const { current, older } = splitByAge(filtered);
  const currentRelated = selected ? relatedNews(selected, current).slice(0, 4) : current.slice(0, 4);
  const olderRelated = selected ? relatedNews(selected, older).slice(0, 4) : older.slice(0, 4);
  const currentRest = current.filter((item) => item.id !== selected?.id && !currentRelated.some((row) => row.id === item.id)).slice(0, 3);
  const olderRest = older.filter((item) => item.id !== selected?.id && !olderRelated.some((row) => row.id === item.id)).slice(0, 3);
  const calls = sourceCalls(filtered);
  const ai = selected ? reads[selected.id] : undefined;
  const extra = selected ? clash(selected, tech.vtun.bias) : null;

  async function askAi() {
    if (!selected || running) return;
    setRunning(true);
    setError(null);
    const result = await readNews({
      data: {
        title: selected.title,
        source: selected.source,
        note: selected.note,
        publishedAt: selected.publishedAt ? formatWhen(selected.publishedAt) : "",
        current: current.slice(0, 6).map((item) => ({
          title: item.title,
          source: item.source,
          publishedAt: item.publishedAt ? formatWhen(item.publishedAt) : "",
        })),
        older: older.slice(0, 6).map((item) => ({
          title: item.title,
          source: item.source,
          publishedAt: item.publishedAt ? formatWhen(item.publishedAt) : "",
        })),
        calls: calls.slice(0, 8).map((item) => ({ source: item.source, claim: item.claim })),
        tech: [...(tech.m5 ? [tech.m5.vsWeek, tech.m5.vsDay, tech.m5.cvdNote, tech.m5.obvNote] : []), ...(tech.h1 ? [tech.h1.vsWeek, tech.h1.vsDay, tech.h1.cvdNote, tech.h1.obvNote] : [])].join(
          " ",
        ),
        risks: tech.risks.map((item) => `${item.title}: ${item.detail}`).join(" "),
        vtun: `${tech.vtun.headline} Lý do: ${tech.vtun.reasons.join(" ")}`,
      },
    });
    setRunning(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setReads((prev) => ({ ...prev, [selected.id]: result.read }));
  }

  return (
    <div className="grid gap-4">
      <div className="flex gap-2 overflow-x-auto">
        {FILTERS.map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={`h-11 shrink-0 rounded-lg border px-3 text-sm ${filter === id ? "border-gold text-fg" : "border-line text-muted"}`}
          >
            {label}
          </button>
        ))}
      </div>

      <label className="block text-sm">
        <span className="mb-1 block text-xs text-muted">Chọn tin để đọc</span>
        <select
          value={selected?.id ?? ""}
          onChange={(event) => setPicked(event.target.value)}
          className="h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm text-fg"
        >
          {filtered.map((item) => (
            <option key={item.id} value={item.id}>
              {(item.source || "Nguồn")} — {item.title}
            </option>
          ))}
        </select>
      </label>
      {filtered.length === 0 ? <p className="text-sm text-muted">Không có tin khớp bộ lọc.</p> : null}

      {selected ? (
        <article className="rounded-xl border border-line bg-bg p-4">
          <p className="font-mono text-xs tracking-widest text-muted">TIN ĐANG ĐỌC</p>
          <h2 className="mt-2 font-serif text-2xl">{selected.title}</h2>
          <p className="mt-2 text-sm text-muted">
            Nguồn: {selected.source || "không rõ nguồn"} · {selected.publishedAt ? formatWhen(selected.publishedAt) : "không rõ giờ"} · {leanWord(selected.lean)}
          </p>
          <p className="mt-2 text-sm">{selected.note}</p>
          {selected.link ? (
            <a href={selected.link} target="_blank" rel="noreferrer" className="mt-3 inline-flex h-11 items-center text-sm text-gold">
              Mở bài gốc
            </a>
          ) : null}
        </article>
      ) : null}

      <section className="grid gap-2">
        <h2 className="font-serif text-xl">Cảnh báo</h2>
        {tech.topRisk === "thấp" && !extra ? (
          <p className="text-sm text-muted">Chưa có cảnh báo tiềm ẩn. VP WEEK, VP DAY, VWAP và CVD/OBV chưa lệch đủ để gắn rủi ro cao.</p>
        ) : (
          <div className="grid gap-2">
            {tech.risks.map((risk) => (
              <div key={risk.detail} className={`rounded-xl border p-4 ${risk.level === "cao" ? "border-down bg-raised" : "border-gold bg-surface"}`}>
                <p className={`font-mono text-xs tracking-widest ${risk.level === "cao" ? "text-down" : "text-gold"}`}>{risk.title}</p>
                <p className="mt-1 text-sm">{risk.detail}</p>
              </div>
            ))}
            {extra ? (
              <div className="rounded-xl border border-gold bg-surface p-4">
                <p className="font-mono text-xs tracking-widest text-gold">Tiềm ẩn</p>
                <p className="mt-1 text-sm">{extra}</p>
              </div>
            ) : null}
          </div>
        )}
      </section>

      <section>
        <h2 className="font-serif text-xl">Kỹ thuật M5 và H1</h2>
        <p className="mt-1 text-sm text-muted">
          VP DAY {tech.dayTag} · VP WEEK {tech.weekTag} · nến đến {formatWhen(tech.asOf)}. Bốn công cụ: VP WEEK, VP DAY, VWAP, CVD/OBV DIV.
        </p>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <FrameCard frame={tech.m5} empty="Chưa đủ nến M5." />
          <FrameCard frame={tech.h1} empty="Chưa đủ nến H1." />
        </div>
      </section>

      <VtunCard call={tech.vtun} />

      <section>
        <h2 className="font-serif text-xl">Dự đoán của nguồn khác</h2>
        <p className="mt-1 text-sm text-muted">Chỉ ghi khi tiêu đề là một nhận định hướng tới. Mỗi dòng giữ tên nguồn.</p>
        {calls.length === 0 ? (
          <p className="mt-3 text-sm text-muted">Trong bộ tin này chưa thấy dự đoán của người khác. Tin sự kiện không bị ghi thành dự đoán.</p>
        ) : (
          <ul className="mt-3 grid gap-3">
            {calls.map((call) => (
              <li key={call.id} className="rounded-xl border border-line bg-surface p-4 text-sm">
                <p className="text-xs text-muted">Theo {call.source} · {call.publishedAt ? formatWhen(call.publishedAt) : "không rõ giờ"}</p>
                <p className="mt-1">{call.claim}</p>
                {call.link ? (
                  <a href={call.link} target="_blank" rel="noreferrer" className="mt-2 inline-flex h-11 items-center text-gold">
                    Nguồn
                  </a>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="grid gap-3 md:grid-cols-2">
        <HeadlineList title="Tin hiện" hint="36 giờ qua, giờ GMT+7" items={currentRelated} rest={currentRest} empty="Không có tin hiện cùng chủ đề." />
        <HeadlineList title="Tin cũ" hint="Trước đó, trong 7 ngày" items={olderRelated} rest={olderRest} empty="Không có tin cũ cùng chủ đề." />
      </section>

      <section className="rounded-xl border border-line bg-surface p-4">
        <h2 className="font-serif text-xl">Dự đoán của AI</h2>
        <p className="mt-1 text-sm text-muted">Không ký tên VTUN. Nếu nhắc người khác thì phải có nguồn. Bấm mới chạy, không tự gọi.</p>
        <Button type="button" className="mt-3" variant="line" onClick={() => void askAi()} disabled={!selected || running}>
          {running ? "Đang đọc…" : "Nhờ AI đọc tin này"}
        </Button>
        {error ? <p className="mt-3 text-sm text-down">{error}</p> : null}
        {ai ? <AiCard read={ai} /> : null}
      </section>
    </div>
  );
}

function FrameCard({ frame, empty }: { frame: FrameRead | null; empty: string }) {
  if (!frame) {
    return (
      <article className="rounded-xl border border-line bg-surface p-4">
        <p className="text-sm text-muted">{empty}</p>
      </article>
    );
  }
  return (
    <article className="rounded-xl border border-line bg-surface p-4">
      <p className="font-mono text-xs tracking-widest text-gold">{frame.tf}</p>
      <p className="mt-1 font-mono text-sm tabular-nums">
        {formatPx(frame.last)} <span className="text-muted">· {frame.bars} nến</span>
      </p>
      <dl className="mt-3 grid gap-3 text-sm">
        <div>
          <dt className="text-xs text-muted">VP WEEK</dt>
          <dd className="mt-1">{frame.vsWeek}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">VP DAY</dt>
          <dd className="mt-1">{frame.vsDay}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">VWAP</dt>
          <dd className="mt-1">
            {frame.vwap != null ? formatPx(frame.vwap) : "thiếu"} · {frame.vwapLabel}
            {frame.vwapDistPct != null ? ` · cách ${frame.vwapDistPct > 0 ? "+" : ""}${frame.vwapDistPct.toFixed(2)}%` : ""}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-muted">CVD / OBV DIV</dt>
          <dd className="mt-1">
            <p className={divClass(frame.cvdDiv, frame.cvdFresh)}>CVD · {divWord(frame.cvdDiv, frame.cvdFresh)}</p>
            <p className={divClass(frame.obvDiv, frame.obvFresh)}>OBV · {divWord(frame.obvDiv, frame.obvFresh)}</p>
            <p className="mt-1 text-muted">{frame.cvdNote}</p>
            <p className="text-muted">{frame.obvNote}</p>
          </dd>
        </div>
      </dl>
      {frame.volumeNote ? <p className="mt-3 text-xs text-muted">{frame.volumeNote}</p> : null}
    </article>
  );
}

function VtunCard({ call }: { call: VtunCall }) {
  return (
    <section className="rounded-xl border border-gold bg-surface p-4">
      <p className="font-mono text-xs tracking-widest text-gold">DỰ ĐOÁN CỦA VTUN</p>
      <h2 className="mt-2 font-serif text-2xl">{biasWord(call.bias)}</h2>
      <p className="mt-2 text-sm">{call.headline}</p>
      <h3 className="mt-4 font-serif text-xl">Lý do</h3>
      <ol className="mt-2 grid list-decimal gap-2 pl-5 text-sm">
        {call.reasons.map((reason) => (
          <li key={reason}>{reason}</li>
        ))}
      </ol>
      <h3 className="mt-4 font-serif text-xl">Điều làm hỏng</h3>
      <p className="mt-2 text-sm text-muted">{call.invalidation}</p>
    </section>
  );
}

function HeadlineList({
  title,
  hint,
  items,
  rest,
  empty,
}: {
  title: string;
  hint: string;
  items: NewsItem[];
  rest: NewsItem[];
  empty: string;
}) {
  return (
    <section className="rounded-xl border border-line bg-surface p-4">
      <h2 className="font-serif text-xl">{title}</h2>
      <p className="mt-1 text-xs text-muted">{hint}</p>
      {items.length === 0 ? <p className="mt-3 text-sm text-muted">{empty}</p> : null}
      <ul className="mt-3 grid gap-3">
        {items.map((item) => (
          <li key={item.id} className="text-sm">
            <p className="text-xs text-muted">
              {item.source || "không rõ nguồn"} · {item.publishedAt ? formatWhen(item.publishedAt) : "không rõ giờ"}
            </p>
            <p className="mt-1">{item.title}</p>
          </li>
        ))}
      </ul>
      {rest.length ? (
        <div className="mt-4 border-t border-line pt-3">
          <p className="text-xs text-muted">Tin khác trong nhóm</p>
          <ul className="mt-2 grid gap-2">
            {rest.map((item) => (
              <li key={item.id} className="text-sm text-muted">
                {item.source ? `${item.source}: ` : ""}
                {item.title}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

function AiCard({ read }: { read: AiRead }) {
  return (
    <div className="mt-4 grid gap-3 text-sm">
      <p className="text-muted">{biasWord(read.bias)} · bài của AI, không phải VTUN</p>
      <div>
        <h3 className="font-serif text-xl">Tin hiện</h3>
        <p className="mt-1">{read.now || "AI không tóm được tin hiện."}</p>
      </div>
      <div>
        <h3 className="font-serif text-xl">Tin cũ</h3>
        <p className="mt-1">{read.past || "AI không thấy khác biệt với tin cũ."}</p>
      </div>
      <div>
        <h3 className="font-serif text-xl">Nguồn khác</h3>
        {read.cited.length === 0 ? (
          <p className="mt-1 text-muted">AI không dẫn thêm dự đoán của người khác.</p>
        ) : (
          <ul className="mt-1 grid gap-2">
            {read.cited.map((cite) => (
              <li key={`${cite.source}-${cite.claim}`}>
                Theo {cite.source}: {cite.claim}
              </li>
            ))}
          </ul>
        )}
      </div>
      <div>
        <h3 className="font-serif text-xl">Dự đoán của AI</h3>
        <p className="mt-1">{read.prediction}</p>
      </div>
      {read.risks.length ? (
        <div>
          <h3 className="font-serif text-xl">Cảnh báo AI nhắc lại</h3>
          <ul className="mt-1 grid gap-1 text-muted">
            {read.risks.map((risk) => (
              <li key={risk}>{risk}</li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
