import { createFileRoute } from "@tanstack/react-router";
import { DeskApp } from "@/components/desk-app";
import { getDesk } from "@/lib/market.functions";

export const Route = createFileRoute("/")({
  loader: () => getDesk({ data: { fresh: false } }),
  pendingComponent: Pending,
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  return <DeskApp initial={initial} />;
}

function Pending() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-16">
      <p className="font-mono text-xs tracking-widest text-gold">AURUM</p>
      <h1 className="mt-2 font-serif text-4xl">Đang gom dữ liệu XAUUSD…</h1>
      <p className="mt-3 max-w-md text-sm text-muted">Giá, nến M5/H1, và tin bảy ngày theo giờ GMT+7.</p>
    </main>
  );
}
